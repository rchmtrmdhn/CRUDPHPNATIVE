<?php 
include 'koneksi2.php';
include "library/header.php";

 ?> 

<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
<link href="load-more-button.css" rel="stylesheet">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<div class="interior container clearfix">
   <div class="row"> 
      <div class="col-xs-12 col-sm-6 col-md-12 blogBox">
         <div class="item featured">
            <img src="https://www.solodev.com/assets/fancy/travel3.jpg">
            <div class="blogTxt">
               <div class="blogCategory">
                  <a href="/">Business Intelligence</a>
               </div>
               <h2>
                  Eu qui dolore altera, saepe molestie accusamus
               </h2>
               <p class="post_intro hidden-xs">
                  An erant partem albucius quo, ad graece latine atomorum sea, sit dicant laoreet at. Id has chor...
               </p>
            </div>
         </div>
      </div>

      <div class="col-xs-12 col-sm-6 col-md-4 blogBox moreBox" >               
         <div class="item">

            <?php

            $sql="SELECT * FROM `dt_member`";            
            $query = mysqli_query($con,$sql) or die(mysqli_error($con));
            $jumlah = mysqli_num_rows($query);

               
         
            ?>                                  

               <?php                  
                  $no = 1;
                  while($hasil = mysqli_fetch_object($query)){
               ?>                        

                             
            <div class="item">                              
               <table>
                     <tr>
                        <th><?php echo $no ?></th>
                        <td><img src="img/<?php echo $hasil->foto?>"></td>
               <div class="blogCategory">                  
                  
                  <a href="/">AAAAA</a>
                    
               </div>
               <h2>
                  Ea delicata deterru isset concluda turque
               </h2>
               <p class="post_intro hidden-xs">
                  Mel ut enim atqui, ne eum tation populo delectus. Vim soluta insolens phaedrum et, lucilius par...
               </p>
            </div>
            </tr>
       <?php 
                  $no++;    
               } ?>
      </table>    
         </div>                 
      </div>            
      <div id="loadMore" style="">
         <a href="#">Load More</a>
      </div>
   </div>
</div>


<script>
$( document ).ready(function () {
		$(".moreBox").slice(0, 3).show();
		if ($(".blogBox:hidden").length != 0) {
			$("#loadMore").show();
		}		
		$("#loadMore").on('click', function (e) {
			e.preventDefault();
			$(".moreBox:hidden").slice(0, 6).slideDown();
			if ($(".moreBox:hidden").length == 0) {
				$("#loadMore").fadeOut('slow');
			}
		});
	});
</script>

<?php
include "library/footerdisdik.php";
?>