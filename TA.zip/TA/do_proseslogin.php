<?php
	include "koneksi.php";
	
	$aemail= $_POST["aemail"];
	$password= $_POST["password"];


	session_start();	
	$admin = "SELECT * FROM `rb_admin` WHERE `aemail` ='".$aemail."' AND `password` ='".md5($password)."' ";
	$user = "SELECT * FROM `rb_users` WHERE `aemail` ='".$aemail."' AND `password` ='".md5($password)."'"; 
	$login = mysqli_query($con,$user);
	$loginadmin = mysqli_query($con,$admin);

	if (mysqli_num_rows($login)>0) {
		$_SESSION['user'] = $aemail;
		$_SESSION['password'] = $password;
		header("location:user_sekolah/home.php");	
	}
	elseif (mysqli_num_rows($loginadmin)>0) {
		$_SESSION['admin'] = $aemail;
		$_SESSION['password'] = $password;
		header("location:user_disdik/home.php");	
	}
	else{
	 	header("location:index.php?salah=<center><strong>Username dan Password salah!</strong></center>");	
	}
	// session_start();
	// if(mysqli_num_rows($hasilmember) > 0){
	// 	$_SESSION["txt_username"] = $username;
	// 	$_SESSION["txt_password"] = $password;
	// 	header("location:../murid/beranda.php");
	// 	echo "Berhasil Login";	

	// }else if(mysqli_num_rows($hasilguru) > 0){
	// 	$_SESSION['txt_username'] = $username;
	// 	$_SESSION['txt_password'] = $password;
	// 	header("location:../guru/beranda.php");

	// }else{		
	// 	header("location:../masuk.php?salah=Username dan Password salah!");	
	// }




?>


<!-- dt_member bisa di ganti ms_member
	dt = data
	ms = master	
 -->