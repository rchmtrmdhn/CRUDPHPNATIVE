
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>DISDIK - TENDIK</title>
  <link rel="stylesheet" href="../css/bootstrap.min.css">
  <link rel="stylesheet" href="../css/fontawesome-all.min.css">
  <link rel="stylesheet" href="../css/jcarousel.basic.css">
  <!-- <link rel="stylesheet" href="../css/baris.css"> -->

  <link rel="stylesheet" href="../plugin/jquery-ui-1.12.1.custom/jquery-ui.css">

  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">

  <link href='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css' rel='stylesheet' type='text/css'> 
  <link href='https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap.min.css' rel='stylesheet' type='text/css'> 
  <!-- BOOTSTRAP STYLES-->
  <link href="../assets/css/bootstrap.css" rel="stylesheet" />
  <!-- FONTAWESOME STYLES-->
  <link href="../assets/css/font-awesome.css" rel="stylesheet" />
  <!-- CUSTOM STYLES-->
  <link href="../assets/css/custom.css" rel="stylesheet" />
  <!-- GOOGLE FONTS-->
  <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />

  <link href="../css/alert.css" rel="stylesheet" />

  <link rel="shortcut icon" href="../img/logo2.jpg">       
</head>
<body>
  <div id="wrapper">
    <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
          <span class="sr-only">Toggle navigation</span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href="home.php">User Sekolah</a> 
      </div>
      <div style="color: white;
      padding: 15px 50px 5px 50px;
      float: right;
      font-size: 16px;"> &nbsp; 
      <a href="ubah_sandi.php" class="btn btn-danger square-btn-adjust"><i class="fa fa-key fa-1x"></i> Change Password</a> 
      <a href="../user_sekolah/proses/do_logout.php" class="btn btn-danger square-btn-adjust"><i class="fa fa-sign-out fa-1x"></i> Logout</a>                         
    </div>            
    <div style="color: white;
    padding: 15px 50px 5px 50px;
    float: left;
    font-size: 16px;"> &nbsp;             
    <a href="home.php" class="btn btn-danger square-btn-adjust"><i class="fa fa-home fa-1x"></i> Home</a> 
    <a href="download.php" class="btn btn-danger square-btn-adjust"><i class="fa fa-download fa-1x"></i> Format Download</a> 
    <a href="kirim_pesan.php?id=<?php echo $hasil->id_user ?>" class="btn btn-danger square-btn-adjust"><i class="fa fa-envelope fa-1x"></i> Contact Disdik</a> 
    <a href="#.php" class="btn btn-danger square-btn-adjust"><i class="fa fa-info-circle fa-1x"></i> Info Penting</a> 

  </div>            
</nav>   
<!-- /. NAV TOP  -->
<nav class="navbar-default navbar-side" role="navigation">
  <div class="sidebar-collapse">
    <ul class="nav" id="main-menu">
      <li class="text-center">
        <img src="../assets/img/find_user.png" class="user-image img-responsive"/>
      </li>                    
      <li>
        <a class="active-menu" href="home.php"><center> Welcome, <?php echo $_SESSION['user']; ?></center></a>
      </li>    
      <li>
        <a href="home.php"><i class="fa fa-dashboard fa-1x"></i> Dashboard</a>
      </li>                    
      <li>
        <a href="#"><i class="fa fa-book fa-1x"></i>Report<span class="fa arrow"></span></a>
        <ul class="nav nav-second-level">                            
          <li>
            <a href="datapendidik&kependidikan.php">Data Pendidik & Kependidikan</a>
          </li>                             
        </ul>
      </li>
      <li>
        <a href="#"><i class="fa fa-book fa-1x"></i>Project<span class="fa arrow"></span></a>
        <ul class="nav nav-second-level">
          <li>
            <a href="daftaragenda.php">Daftar Agenda</a>
          </li>
          <li>
            <a href="ceklaporan.php">Cek Laporan User</a>
          </li>                             
        </ul>
      </li>                                                             
    </ul>

  </div>

</nav>  
