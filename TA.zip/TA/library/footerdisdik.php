
<!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->

<script src="../js/jquery-3.3.1.min.js"></script>
<script src="../js/jquery.cycle.all.js"></script>
<script src="../js/jquery.jcarousel.min.js"></script>
<script src="../js/jcarousel.basic.js"></script>
<script src="../js/bootstrap.min.js"></script>		
<script src="../js/datatables.js"></script>


<!-- JQUERY SCRIPTS -->
<script src="../assets/js/jquery-1.10.2.js"></script>
<!-- BOOTSTRAP SCRIPTS -->
<script src="../assets/js/bootstrap.min.js"></script>
<!-- METISMENU SCRIPTS -->
<script src="../assets/js/jquery.metisMenu.js"></script>
<!-- CUSTOM SCRIPTS -->
<script src="../assets/js/custom.js"></script>

<script src="../js/alert.js"></script>
<script src="../js/highcharts.js" type="text/javascript"></script>
<script src="../plugin/jquery-ui-1.12.1.custom/jquery-ui.js"></script>
<script src="../plugin/fancybox-master/dist/jquery.fancybox.min.js"></script>

<script src="https://code.jquery.com/jquery-3.3.1.js"></script>
<script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap.min.js"></script>
<script>
  var ctx = document.getElementById("myChart").getContext('2d');
  var myChart = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: ["pendidik", "kependidikan"],
      datasets: [{
        label: '',
        data: [
        <?php 
        $jumlah_pendidik = mysqli_query($con,$sql2);
        echo mysqli_num_rows($jumlah_pendidik);
        ?>, 
        <?php 
        $jumlah_kependidikan = mysqli_query($con,$sql3);
        echo mysqli_num_rows($jumlah_kependidikan);
        ?>
        ],
        backgroundColor: [
        'rgba(51,255,0,0.2)',
        'rgba(54, 162, 235, 0.2)'
        ],
        borderColor: [
        'rgba(51,255,0,0.2)',
        'rgba(54, 162, 235, 1)'
        ],
        borderWidth: 3
      }]
    },
    options: {
      scales: {
        yAxes: [{
          ticks: {
            beginAtZero:true
          }
        }]
      }
    }
  });
</script>
</body>
</html>