

<script src="js/jquery.cycle.all.js"></script>
<script src="js/jquery.jcarousel.min.js"></script>
<script src="js/jcarousel.basic.js"></script>	
<script src="js/datatables.js"></script>


<script src="plugin/jquery-ui-1.12.1.custom/jquery-ui.js"></script>
<script src="plugin/fancybox-master/dist/jquery.fancybox.min.js"></script>


<script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap.min.js"></script>

