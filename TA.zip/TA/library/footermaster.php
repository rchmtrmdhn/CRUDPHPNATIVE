
<script src="../../js/jquery-3.3.1.min.js"></script>
<script src="../../js/jquery.cycle.all.js"></script>
<script src="../../js/jquery.jcarousel.min.js"></script>
<script src="../../js/jcarousel.basic.js"></script>
<script src="../../js/bootstrap.min.js"></script>		
<script src="../../js/datatables.js"></script>


<!-- JQUERY SCRIPTS -->
<script src="../../assets/js/jquery-1.10.2.js"></script>
<!-- BOOTSTRAP SCRIPTS -->
<script src="../../assets/js/bootstrap.min.js"></script>
<!-- METISMENU SCRIPTS -->
<script src="../../assets/js/jquery.metisMenu.js"></script>
<!-- CUSTOM SCRIPTS -->
<script src="../../assets/js/custom.js"></script>

<script src="../../js/alert.js"></script>

<script src="../../plugin/jquery-ui-1.12.1.custom/jquery-ui.js"></script>
<script src="../../plugin/fancybox-master/dist/jquery.fancybox.min.js"></script>

<script src="https://code.jquery.com/jquery-3.3.1.js"></script>
<script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap.min.js"></script>




</body>
</html>