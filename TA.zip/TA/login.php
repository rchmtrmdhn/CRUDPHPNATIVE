<?php 
include 'koneksi.php';
include "library/header.php";

 ?> 
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    

</head>
<body>
    

<section id="tabel" >
      <div class="container">
        <div class="row">
          <div class="col-lg-12 text-center">
            <div class="section-title">
              <h2>TABEL</h2>
              <p>A creative agency based on Candy Land, ready to boost your business with some beautifull templates. Lattes Agency is one of the best in town see more you will be amazed.</p>
                               
        <?php
              if(!empty($_GET["cari"])){
                $sql="SELECT * FROM `dt_user` WHERE `username` LIKE '%".$_GET["cari"]."%'";
              }else{
                $sql="SELECT * FROM `dt_user`";
              }

              $query = mysqli_query($con,$sql) or die(mysqli_error($con));
              $jumlah = mysqli_num_rows($query);

              if($jumlah==0){
                echo "Data Tidak ada";
              }else{
                ?>
                <br>

                <center>
                  <table id="example" class="table table-bordered" style="width:100%">
                  <thead>                                    
                    <tr>
                      <th>No.</th>
                      <th>No. Meja</th>
                      <th>Nama Pengguna</th>
                      <th>Departemen</th>
                      <th>Jabatan</th>
                      <th>Perangkat</th>
                      <th>Windows</th>
                      <th>Ms. Office</th>
                      <th>Host Name</th>
                      <th>MAC Address</th>                    
                      <th>Aplikasi</th>   
                      <th><center>Aksi</center></th>                                   
                    </tr>
                    </thead>
                    
                    <?php
                    $no = 1;
                    while($hasil = mysqli_fetch_object($query)){
                      ?>
                    
                      <tr>
                        <td><?php echo $no?></td>
                        <td><?php echo $hasil->no_id ?></td>
                        <td><?php echo $hasil->username ?></td>
                        <td><?php echo $hasil->dept ?></td>
                        <td><?php echo $hasil->jabatan ?></td>
                        <td><?php echo $hasil->perangkat ?></td>
                        <td><?php echo $hasil->windows ?></td>
                        <td><?php echo $hasil->office ?></td>
                        <td><?php echo $hasil->host ?></td>
                        <td><?php echo $hasil->mac ?></td>                                                
                        <td><?php echo $hasil->aplikasi ?></td>    
                        <td>
                          <a class="btn btn-primary" href="ubah_user.php?id=<?php echo $hasil->no_id?>"> <span class="fa fa-edit"></span> Ubah</a>                                            
                          <a class="btn btn-danger" href="proses/do_hapus_user.php?id=<?php echo $hasil->no_id?>" onclick="return confirm('Anda yakin mau hapus <?php echo $hasil->no_id?> ?')"><span class="fa fa-trash"></span>Hapus</a>
                        </td>
                      </tr>
                    
                      <?php 
                      $no++;
                    } ?>
                    <tfoot>                                        
                    <tr>
                      <th>No.</th>
                      <th>No. Meja</th>
                      <th>Nama Pengguna</th>
                      <th>Departemen</th>
                      <th>Jabatan</th>
                      <th>Perangkat</th>
                      <th>Windows</th>
                      <th>Ms. Office</th>
                      <th>Host Name</th>
                      <th>MAC Address</th>                    
                      <th>Aplikasi</th>                  
                      <th><center>Aksi</center></th>                           
                    </tr>
                    </tfoot>
                  </table>
                  <?php } ?>
                  
            </div>
          </div>
        </div>
        
      </div>
      <!-- /.container -->
    </section>
   
</body>
</html>
<?php
    include "library/footer.php";
?>    