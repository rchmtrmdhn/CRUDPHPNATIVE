<?php 
include 'koneksi.php';
include "library/header.php";

 ?> 
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
		<meta name="description" content="">
		<meta name="author" content="">
		<link rel="icon" href="favicon.ico">
		<title>TENDIK</title>
		<!-- Bootstrap core CSS -->
		<link href="css/bootstrap.min.css" rel="stylesheet">		
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
		
		<!-- Custom styles for this template -->
		<link href="css/owl.carousel.css" rel="stylesheet">
		<link href="css/owl.theme.default.min.css"  rel="stylesheet">
		<link href="css/style.css" rel="stylesheet">
		<link href="css/mark.css" rel="stylesheet">
		<!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
		<!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
		<script src="js/ie-emulation-modes-warning.js"></script>
		<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
		<!--[if lt IE 9]>
		<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
		<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
		<![endif]-->
	</head>
	<body id="page-top">
		<!-- Navigation -->
		<nav class="navbar navbar-default navbar-fixed-top">
			<div class="container">
				<!-- Brand and toggle get grouped for better mobile display -->
				<div class="navbar-header page-scroll">
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					</button>
					<a class="navbar-brand page-scroll" href="#page-top"><img src="images/tendik.png" alt="Lattes theme logo"></a>
				</div>
				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav navbar-right">
						<li class="hidden">
							<a href="#page-top"></a>
						</li>						
						<li>
							<a class="page-scroll" href="#tabel">Tabel</a>
						</li>												
						<li>
							<a class="page-scroll" href="#sekolah">Sekolah</a>
						</li>						
						<li>
							<a class="page-scroll" href="#jenjang">Jenjang</a>
						</li>					
						<li>
							<a class="page-scroll" href="#kontak">Kontak</a>
						</li>						
						<li>
							<a class="page-scroll" href="#login">Login</a>
						</li>
					</ul>
				</div>
				<!-- /.navbar-collapse -->
			</div>
			<!-- /.container-fluid -->
		</nav>
		<!-- Header -->
		<header>
			<div class="container">
				<div class="slider-container">
					<div class="intro-text">
						<div class="intro-lead-in"><mark> Welcome To Our Website! </mark></div><br>
						<div class="intro-heading"><mark> It's Nice To Meet You </mark></div>
						<a href="#tabel" class="page-scroll btn btn-xl">Tell Me More</a>
					</div>
				</div>
			</div>
		</header>

		<section id="login" class="light-bg">
			<div class="container">
				<div class="row">
					<div class="col-lg-12 text-center">
						<div class="section-title">
							<h2>Login</h2>
							<p>Silahkan login terlebih dahulu untuk mendapatkan akses lebih.</p>
							<div class="col-md-4 col-md-offset-4 col-sm-6 col-sm-offset-3 col-xs-10 col-xs-offset-1">
								<div class="panel panel-default">
									<div class="panel-heading">
										<strong>   TENDIK </strong>  
									</div>
									<div class="panel-body">
										<form role="form" action="do_proseslogin.php" method="post">									
											<br />
											<div class="form-group input-group">
												<span class="input-group-addon"><i class="fa fa-tag"  ></i></span>
												<input id="aemail" name="aemail" type="text" class="form-control" placeholder="Your Username " />
											</div>
											<div class="form-group input-group">
												<span class="input-group-addon"><i class="fa fa-lock"  ></i></span>
												<input id="password" name="password" type="password" class="form-control"  placeholder="Your Password" />
											</div>
											<div class="form-group">
												<label class="checkbox-inline">
													<input type="checkbox" /> Remember me
												</label>
												<span class="pull-right">
													<a href="#" >Forget password ? </a> 
												</span>
											</div>

											<button type="submit" class="btn btn-primary">Masuk </button>
											<hr />
											
										</form>
									</div>

								</div>
							</div>
						</div>
					</div>
				</div>
				
			</div>
			<!-- /.container -->
		</section>

		<section class="overlay-dark bg-img1 dark-bg short-section">
			<div class="container text-center">
				<div class="row">
					<div class="col-md-4 mb-sm-30">
						<div class="counter-item">
						<?php
	                      $sql = "SELECT * FROM `rb_pendidik` WHERE `status` like 'pendidik' ";
	                      $query = mysqli_query($con,$sql) or die(mysqli_error($con));
	                      $jumlah = mysqli_num_rows($query);
	                     ?>
	                      <h2> <?php echo $jumlah?> </h2>
							<h6>Data Pendidik</h6>
						</div>
					</div>				
					<div class="col-md-4 mb-sm-30">
						<div class="counter-item">
						<?php
	                      $sql = "SELECT * FROM `rb_pendidik` WHERE `status` like 'kependidikan' ";
	                      $query = mysqli_query($con,$sql) or die(mysqli_error($con));
	                      $jumlah = mysqli_num_rows($query);
	                     ?>
	                      <h2> <?php echo $jumlah?> </h2>
							<h6>Data Kependidikan</h6>
						</div>
					</div>	
					<div class="col-md-4 mb-sm-30">
						<div class="counter-item">
						<?php
	                      $sql = "SELECT * FROM `rb_pendidik` ";
	                      $query = mysqli_query($con,$sql) or die(mysqli_error($con));
	                      $jumlah = mysqli_num_rows($query);
	                     ?>
	                      <h2> <?php echo $jumlah?> </h2>
							<h6>Data Pendidik & Kependidikan</h6>
						</div>
					</div>					
				</div>
			</div>
		</section>

		<section id="tabel">
			<div class="container">
				<div class="row">
					<div class="col-lg-12 text-center">
						<div class="section-title">
							<h2>TABEL</h2>
							<p>Menyajikan data Pendidik & Kependidikan yang sudah terdaftar.</p>
							                 
				<?php
              
              $sql="SELECT * FROM `rb_pendidik`";            
              $query = mysqli_query($con,$sql) or die(mysqli_error($con));
              $jumlah = mysqli_num_rows($query);

              if($jumlah==0){
                echo "Data Tidak ada";
              }else{
                ?>                

                <center>
                  <table id="example" class="" style="width:100%" border="0">
                  <thead>                                    
                    <tr>
                      <th>No.</th>                      
                      <th>Nama</th>
                      <th>NIP</th>
                      <th>Golongan</th>
                      <th>Jenis Kelamin</th>
                      <th>Bidang Studi</th>
                      <th>Akademik</th>
                      <th>Action</th>                      
                    </tr>
                    </thead>
                    
                    <?php
                    $no = 1;
                    while($hasil = mysqli_fetch_object($query)){
                      ?>
                    
                      <tr>
                        <td><?php echo $no?></td>
                        <td><?php echo $hasil->nama_lengkap ?></td>
                        <td><?php echo $hasil->jika_pns_nip ?></td>
                        <td><?php echo $hasil->pangkat_gol ?></td>
                        <td><?php echo $hasil->jenis_kelamin ?></td>
                        <td><?php echo $hasil->bidang_studi ?></td>
                        <td><?php echo $hasil->akademik ?></td>
                        <td><a class="btn btn-primary" href="ubahpendidik.php?id=<?php echo $hasil->id_pendidik?>"><span class="fa fa-pencil"></span></a></td>                        
                      </tr>
                    
                      <?php 
                      $no++;
                    } ?>
                    <tfoot>                                        
                    <tr>
                      <th>No.</th>                      
                      <th>Nama</th>
                      <th>NIP</th>
                      <th>Golongan</th>
                      <th>Jenis Kelamin</th>
                      <th>Bidang Studi</th>
                      <th>Akademik</th>
                      <th>Action</th>                                                               
                    </tr>
                    </tfoot>
                  </table>
                  <?php } ?>
                  
						</div>
					</div>
				</div>
				
			</div>
			<!-- /.container -->
		</section>

		<section id="sekolah" class="light-bg">
			<div class="container">
				<div class="row">
					<div class="col-lg-12 text-center" >
						<div class="section-title">
							<h2>User Sekolah</h2>
							<p>User Sekolah yang bertanggung jawab sebagai admin sekolah.</p>
						</div>
					</div>
				</div>
				 <center>
              <form method="get" action="#sekolah">
                <input type="text" name="cari" placeholder="Cari Nama Lengkap">
                <button type="submit" class="btn btn-success"><span class="fa fa-search"> Cari</span></button>
                <button type="submit" class="btn btn-primary"><span class="fa fa-refresh"> Tampil Semua</button>
              </form>
            </center>
            <br>
              <?php
              if(!empty($_GET["cari"])){
                $sql="SELECT * FROM `rb_users` WHERE `nama_lengkap` LIKE '%".$_GET["cari"]."%'";
              }else{
                $sql="SELECT * FROM `rb_users`";
              }

              $query = mysqli_query($con,$sql) or die(mysqli_error($con));
              $jumlah = mysqli_num_rows($query);

              if($jumlah==0){
                echo "Data Tidak ada";
              }else{
                ?>                  

				<?php                  
				$no = 1;
				while($hasil = mysqli_fetch_object($query)){
					?>					

					<div class="item">
						<!-- team member item -->
						<div class="col-md-3  blogBox moreBox"  style="display: none;">
							<div class="team-item">
								<?php echo $no?>
								<div class="team-image">
									<img src="img/<?php echo $hasil->foto?>"  style="width:200px; height:150px;" >
								</div>
								<div class="team-text">
									<h3><?php echo $hasil->nama_lengkap?></h3>
									<div class="team-location"><?php echo $hasil->aemail?></div>
									<div class="team-position">– <?php echo $hasil->id_sekolah?> –</div>
									<p>Mida sit una namet, cons uectetur adipiscing adon elit. Aliquam vitae barasa droma.</p>
								</div>							
							</div>
						</div>	

						<!-- end team member item -->	
						<?php 
						$no++;    
					} ?>
					<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
					<div id="loadMore" align="center">
         				 <button class="btn btn-primary" href="#">Load More</button>
     				</div>
     				<?php } ?>
				</div>	
			</div>			
		</section>
				
		<section id="jenjang">
			<div class="container">
			<div class="row">
				<div class="col-lg-12 text-center">
					<div class="section-title">
						<h2>Jenjang Pendidikan</h2>
						<p>Sekolah adalah suatu lembaga yang digunakan untuk kegiatan belajar bagi para pendidik serta menjadi tempat memberi dan juga menerima pelajaran yang sesuai dengan bidangnya.</p>
					</div>
				</div>
			</div>
			<div class="row">
				<!-- start portfolio item -->
				<div class="col-md-4">
					<div class="ot-portfolio-item">
						<figure class="effect-bubba">
							<img src="images/demo/pgsd.jpg" alt="img02" height="235px" />
							<figcaption>
								<h2>SD</h2>
								<p>Sekolah Dasar</p>
								<a href="#" data-toggle="modal" data-target="#Modal-1">View more</a>
							</figcaption>
						</figure>
					</div>
				</div>
				<!-- end portfolio item -->
				<!-- start portfolio item -->
				<div class="col-md-4">
					<div class="ot-portfolio-item">
						<figure class="effect-bubba">
							<img src="images/demo/pgsmp.jpg" alt="img02" height="235px" />
							<figcaption>
								<h2>SMP</h2>
								<p>Sekolah Menengah Pertama</p>
								<a href="#" data-toggle="modal" data-target="#Modal-2">View more</a>
							</figcaption>
						</figure>
					</div>
				</div>
				<!-- end portfolio item -->
				<!-- start portfolio item -->
				<div class="col-md-4">
					<div class="ot-portfolio-item">
						<figure class="effect-bubba">
							<img src="images/demo/pgsma.jpg" alt="img02" height="235px" />
							<figcaption>
								<h2>SMA</h2>
								<p>Sekolah Menengah Atas</p>
								<a href="#" data-toggle="modal" data-target="#Modal-3">View more</a>
							</figcaption>
						</figure>
					</div>
				</div>
				<!-- end portfolio item -->
			</div>
		</section>
		
		
		<section id="kontak" class="light-bg">
			<div class="container">
				<div class="row">
					<div class="col-lg-12 text-center">
						<div class="section-title">
							<h2>Kontak Kami</h2>
							<p>Jika Anda memiliki beberapa Pertanyaan atau butuh Bantuan! Silakan Hubungi Kami!.</p>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-md-3">						
					</div>
					<div class="col-md-3">
						<h3>Kantor Kami</h3>
						<p>Jl. Surapati No. 1</p>
						<p><i class="fa fa-phone"></i> (0365) 41210</p>
						<p><i class="fa fa-envelope"></i> dikpora.jembrana@gmail.com</p>
					</div>
					<div class="col-md-3">
						<h3>Jam Kerja</h3>
						<p><i class="fa fa-clock-o"></i> <span class="day">Senin-Jumat: </span><span>08.00 s/d 15.00</span></p>
						<p><i class="fa fa-clock-o"></i> <span class="day">Sabtu: </span><span>08.00 s/d 12.00</span></p>
						<p><i class="fa fa-clock-o"></i> <span class="day">Minggu: </span><span>Libur</span></p>
					</div>					
				</div>
			</div>
		</section>
		<p id="back-top">
			<a href="#top"><i class="fa fa-angle-up"></i></a>
		</p>
		<footer>
			<div class="container text-center">
				<p>Copyright (c) 2019 <span>- Sistem Informasi Tenaga Pendidik dan Kependidikan - </span>DISPORA JEMBRANA</p>
			</div>
		</footer>

		<!-- Modal for portfolio item 1 -->
		<div class="modal fade" id="Modal-1" tabindex="-1" role="dialog" aria-labelledby="Modal-label-1">
			<div class="modal-dialog" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						<h4 class="modal-title" id="Modal-label-1">Sekolah Dasar</h4>
					</div>
					<div class="modal-body">
						<img src="images/demo/pgsd.jpg" alt="img01" class="img-responsive" />
						<div class="modal-works"><span>SD</span></div>
						<p>Sekolah Dasar (SD) adalah jenjang paling dasar pada pendidikan formal di Indonesia. Sekolah dasar dilaksanakan dalam waktu 6 tahun, mulai dari kelas 1 sampai kelas 6. Siswa kelas 6 diwajibkan untuk mengikuti Ujian Nasional (dahulu Ebtanas) yang mempengaruhi kelulusan atau tidaknya  siswa.</p>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					</div>
				</div>
			</div>
		</div>

		<!-- Modal for portfolio item 2 -->
		<div class="modal fade" id="Modal-2" tabindex="-1" role="dialog" aria-labelledby="Modal-label-2">
			<div class="modal-dialog" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						<h4 class="modal-title" id="Modal-label-2">Sekolah Menengah Pertama</h4>
					</div>
					<div class="modal-body">
						<img src="images/demo/pgsmp.jpg" alt="img01" class="img-responsive" />
						<div class="modal-works"><span>SMP</span></div>
						<p>Sekolah Menengah Pertama ( SMP) merupakan jenjang pendidikan dasar formal di Indonesia setelah menyelesaikan pendidikan sekolah dasar (SD) atau yang sederajat. Sekolah Menengah Pertama  dilaksanakan dalam kurun waktu 3 tahun, mulai dari kelas 7 sampai kelas 9. Siswa kelas 9 diwajibkan mengikuti Ujian Nasional yang mempengaruhi kelulusan atau tidaknya siswa.</p>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					</div>
				</div>
			</div>
		</div>

		<!-- Modal for portfolio item 3 -->
		<div class="modal fade" id="Modal-3" tabindex="-1" role="dialog" aria-labelledby="Modal-label-3">
			<div class="modal-dialog" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						<h4 class="modal-title" id="Modal-label-3">Sekolah Menengah Atas</h4>
					</div>
					<div class="modal-body">
						<img src="images/demo/pgsma.jpg" alt="img01" class="img-responsive" />
						<div class="modal-works"><span>SMA</span></div>
						<p>Sekolah Menengah Atas dalam pendidikan formal di Indonesia, merupakan jenjang pendidikan menengah setelah menamatkan Sekolah Menengah Pertama (SMP) atau yang sederajat. Sekolah Menengah Atas diselesaikan dalam kurun waktu 3 tahun, yaitu mulai kelas 10 sampai kelas 12. Pada tahun kedua (di kelas 11), siswa Sekolah Menengah Atas, wajib memilih jurusan yang ada, yaitu Sains, Sosial, atau Bahasa. Pada akhir tahun ketiga (di kelas 12), siswa diwajibkan mengikuti Ujian Nasional yang mempengaruhi kelulusan atau tidaknya siswa. Setelah lulus (tamat) Sekolah Menengah Atas dapat melanjutkan pendidikan ke perguruan tinggi.</p>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					</div>
				</div>
			</div>
		</div>
		
		<!-- Bootstrap core JavaScript
			================================================== -->
		<!-- Placed at the end of the document so the pages load faster -->
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
		<script src="http://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script src="js/owl.carousel.min.js"></script>
		<script src="js/cbpAnimatedHeader.js"></script>
		<script src="js/theme-scripts.js"></script>
		
		<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
		<script src="js/ie10-viewport-bug-workaround.js"></script>		
	</body>
</html>

<script>
$( document ).ready(function () {
		$(".moreBox").slice(0, 4).show();
		if ($(".blogBox:hidden").length != 0) {
			$("#loadMore").show();
		}		
		$("#loadMore").on('click', function (e) {
			e.preventDefault();
			$(".moreBox:hidden").slice(0, 4).slideDown();
			if ($(".moreBox:hidden").length == 0) {
				$("#loadMore").fadeOut('slow');
			}
		});
	});
</script>

<?php
	include "library/footer.php"
?>