<?php
$aksi="modul/mod_data/aksi_data.php";
switch($_GET[act]){

  default:
  if ($_GET[status] != ''){
	$hitungstatus = mysql_query("SELECT * FROM rb_pendidik where status_guru='$_GET[status]'");
  }else{
	$hitungstatus = mysql_query("SELECT * FROM rb_pendidik");
  }
  
  if ($_GET[akd] != ''){
	$hitungakd = mysql_query("SELECT * FROM rb_pendidik where akademik='$_GET[akd]'");
  }else{
	$hitungakd = mysql_query("SELECT * FROM rb_pendidik");
  }
  
  if ($_GET[bid] != ''){
	$hitungbid = mysql_query("SELECT * FROM rb_pendidik where bidang_studi='$_GET[bid]'");
  }else{
	$hitungbid = mysql_query("SELECT * FROM rb_pendidik");
  }
//  start
	if ($_GET[sek] != ''){
	$hitungsek = mysql_query("SELECT * FROM rb_pendidik where id_sekolah ='$_GET[sek]'");
	}else{
	$hitungsek = mysql_query("SELECT * FROM rb_pendidik");
	}
//  finish
  if ($_GET[kec] != ''){
	$hitungkec = mysql_query("SELECT * FROM rb_pendidik where kecamatan='$_GET[kec]'");
  }else{
	$hitungkec = mysql_query("SELECT * FROM rb_pendidik");
  }
  
  if ($_GET[gol] != ''){
	$hitunggol = mysql_query("SELECT * FROM rb_pendidik where pangkat_gol='$_GET[gol]'");
  }else{
	$hitunggol = mysql_query("SELECT * FROM rb_pendidik");
  }
  
  if ($_GET[data] != ''){
	$hitung = mysql_query("SELECT * FROM rb_pendidik where status='$_GET[data]'");
  }else{
	$hitung = mysql_query("SELECT * FROM rb_pendidik");
  }
  
  if ($_GET[jen] != ''){
	$hitungjen = mysql_query("SELECT * FROM rb_pendidik a left join rb_sekolah b ON a.id_sekolah=b.NSS where b.jenjang_sekolah='$_GET[jen]' AND a.status='$_GET[guru]'");
  }else{
	$hitungjen = mysql_query("SELECT * FROM rb_pendidik");
  }
  
  $total = mysql_num_rows($hitung);
  $totalstatus = mysql_num_rows($hitungstatus);
  $totalakd = mysql_num_rows($hitungakd);
  $totalgol = mysql_num_rows($hitunggol);
  $totaljen = mysql_num_rows($hitungjen);
  $totalbid = mysql_num_rows($hitungbid);
  $totalsek = mysql_num_rows($hitungsek);
  $totalkec = mysql_num_rows($hitungkec);
	if ($_GET[status] != ''){
		echo "<div class='alert alert-info'>Semua Data Guru <b style='text-transform:capitalize;'>$_GET[status] - $totalstatus Orang</b>. 
				<a target='_BLANK' style='float:right; margin-top:-5px;' class='btn btn-primary' href='print-data.php?status=$_GET[status]'>Print Semua Data $_GET[status]</a>
				<a href='#myExcel' role='button' data-toggle='modal' style='float:right; margin-top:-5px; margin-right:3px;' class='btn btn-danger'>Export Excel</a></div><hr>";
	}elseif ($_GET[data] != ''){
		echo "<div class='alert alert-info'>Semua Data <b style='text-transform:capitalize;'>$_GET[data] - $total Orang</b>.
				<a target='_BLANK' style='float:right; margin-top:-5px;' class='btn btn-primary' href='print-data.php?data=$_GET[data]'>Print Semua Data $_GET[data]</a>
				<a href='#myExcel' role='button' data-toggle='modal' style='float:right; margin-top:-5px; margin-right:3px;' class='btn btn-danger'>Export Excel</a></div><hr>";
	}elseif ($_GET[akd] != ''){
		echo "<div class='alert alert-info'>Semua Data Guru <b style='text-transform:capitalize;'>$_GET[akd] - $totalakd Orang</b>. 
				<a target='_BLANK' style='float:right; margin-top:-5px;' class='btn btn-primary' href='print-data.php?akd=$_GET[akd]'>Print Semua Data $_GET[akd]</a>
				<a href='#myExcel' role='button' data-toggle='modal' style='float:right; margin-top:-5px; margin-right:3px;' class='btn btn-danger'>Export Excel</a></div><hr>";
	}elseif ($_GET[kec] != ''){
		echo "<div class='alert alert-info'>Semua Data Guru di Kecamatan <b style='text-transform:capitalize;'>$_GET[kec] - $totalkec Orang</b>. 
				<a target='_BLANK' style='float:right; margin-top:-5px;' class='btn btn-primary' href='print-data.php?kec=$_GET[kec]'>Print Semua Data $_GET[kec]</a>
				<a href='#myExcel' role='button' data-toggle='modal' style='float:right; margin-top:-5px; margin-right:3px;' class='btn btn-danger'>Export Excel</a>
				</div><hr>";
//		start
	}elseif ($_GET[sek] != ''){
		echo "<div class='alert alert-info'>Sekolah <b style='text-transform:capitalize;'>$_GET[bid] - $totalsek Orang</b>. 
				<a target='_BLANK' style='float:right; margin-top:-5px;' class='btn btn-primary' href='print-data.php?bid=$_GET[bid]'>Print Semua Data $_GET[bid]</a>
				<a href='#myExcel' role='button' data-toggle='modal' style='float:right; margin-top:-5px; margin-right:3px;' class='btn btn-danger'>Export Excel</a></div><hr>";
//		finish
	}elseif ($_GET[bid] != ''){
		echo "<div class='alert alert-info'>Semua Data Guru <b style='text-transform:capitalize;'>$_GET[bid] - $totalbid Orang</b>. 
				<a target='_BLANK' style='float:right; margin-top:-5px;' class='btn btn-primary' href='print-data.php?bid=$_GET[bid]'>Print Semua Data $_GET[bid]</a>
				<a href='#myExcel' role='button' data-toggle='modal' style='float:right; margin-top:-5px; margin-right:3px;' class='btn btn-danger'>Export Excel</a></div><hr>";
	}elseif ($_GET[gol] != ''){
		echo "<div class='alert alert-info'>Semua Data Guru Golongan <b style='text-transform:capitalize;'>$_GET[gol] - $totalgol Orang</b>. 
				<a target='_BLANK' style='float:right; margin-top:-5px;' class='btn btn-primary' href='print-data.php?gol=$_GET[gol]'>Print Semua Data $_GET[gol]</a>
				<a href='#myExcel' role='button' data-toggle='modal' style='float:right; margin-top:-5px; margin-right:3px;' class='btn btn-danger'>Export Excel</a></div><hr>";
	}elseif ($_GET[jen] != ''){
		echo "<div class='alert alert-info'>Semua Data $_GET[guru] <b style='text-transform:capitalize;'>$_GET[jen] - $totaljen Orang</b>. 
				<a target='_BLANK' style='float:right; margin-top:-5px;' class='btn btn-primary' href='print-data.php?jen=$_GET[jen]&gurup=$_GET[guru]'>Print Semua Data $_GET[jen]</a>
				<a href='#myExcel' role='button' data-toggle='modal' style='float:right; margin-top:-5px; margin-right:3px;' class='btn btn-danger'>Export Excel</a></div><hr>";
	}else{
		echo "<div class='alert alert-info'>Semua Data <b style='text-transform:capitalize;'>Pendidik dan Kependidikan - $total Orang</b>.
				<a href='#myExcel' role='button' data-toggle='modal' style='float:right; margin-top:-5px; margin-right:3px;' class='btn btn-danger'>Export Excel</a></div><hr>";
	}
	
	
	echo "<input style='margin-right:4px;' class='btn btn-primary' type=button value='Tambah Data' onclick=\"window.location.href='?module=data&act=tambahdata';\">";
		if ($_GET[data] != ''){
				echo " <a target='_BLANK' class='btn btn-success' href='print-data.php?data=$_GET[data]'>Print $_GET[data]</a>
					  <a target='_BLANK'class='btn btn-info' href='?module=data&act=grafik&data=$_GET[data]'>Grafik Tahunan</a>
					  <a target='_BLANK'class='btn btn-info' href='?module=data&act=jenis'>Grafik Jenis Sekolah</a>";
			}else{
				echo "<a target='_BLANK'class='btn btn-success' href='print-data.php'>Print Semua Data</a>
					  <a target='_BLANK'class='btn btn-info' href='?module=data&act=grafik'>Grafik Tahunan</a>
					  <a target='_BLANK'class='btn btn-info' href='?module=data&act=jenis'>Grafik Jenis Sekolah</a>";
			}
		echo "<form style='float:right;' method='post' enctype='multipart/form-data' action='import-csv.php'>
			Data : <input style='border:1px solid #cecece;' type='file' name='filename'>
			<input name='upload' type='submit' value='Import' class='btn btn-success'>
			<a href='downlot.php?file=contoh-data.csv' class='btn'>Contoh Format</a>
		</form><hr><br>
		
		<div style='float:right;'>";
		if ($_GET[data] != '' OR $_GET[guru] != ''){
			?><select style=' margin-right:3px; margin-bottom:5px;' ONCHANGE="location = this.options[this.selectedIndex].value;">
			<?php 
				if ($_GET[jen] != ''){
					echo "<option value='$_GET[jen]' selected>Jenjang $_GET[jen]</option>";
				}else{
					echo "<option value='0' selected>- Jenjang -</option>";
				}
						$akd = mysql_query("SELECT * FROM mt_jenjang");
						while ($a = mysql_fetch_array($akd)){
							if ($_GET[guru] !=''){
								echo "<option value='media.php?module=data&guru=$_GET[guru]&jen=$a[jenjang]'>$a[jenjang]</option>";
							}else{
								echo "<option value='media.php?module=data&guru=$_GET[data]&jen=$a[jenjang]'>$a[jenjang]</option>";
							}
						}
					 
			echo "</select>";
			
		}else{
			?>Filter :
	<select style=' margin-right:3px; margin-bottom:5px;' ONCHANGE="location = this.options[this.selectedIndex].value;">
			<?php 
				if ($_GET[kec] != ''){
					echo "<option value='$_GET[kec]' selected>$_GET[kec]</option>";
				}else{
					echo "<option value='0' selected>- Kecamatan -</option>";
				}
						$akd = mysql_query("SELECT * FROM mt_kecamatan");
						while ($a = mysql_fetch_array($akd)){
							echo "<option value='media.php?module=data&kec=$a[kecamatan]'>$a[kecamatan]</option>";
						}
					 
			echo "</select>";
			
			?>
<!--		start-->
		<select style=' margin-right:3px; margin-bottom:5px;' ONCHANGE="location = this.options[this.selectedIndex].value;">
			<?php
			if ($_GET[sek] != ''){
				echo "<option value='$_GET[rb_s]' selected>$_GET[sek]</option>";
			}else{
				echo "<option value='0' selected>- Sekolah -</option>";
			}
			$rb_s = mysql_query("SELECT * FROM rb_sekolah");
			while ($a = mysql_fetch_array($rb_s)){
				echo "<option value='media.php?module=data&bid=$a[id_sekolah]'>$a[nama_sekolah]</option>";
			}

			echo "</select>";

			?>
<!--		finish-->
		<select style=' margin-right:3px; margin-bottom:5px;' ONCHANGE="location = this.options[this.selectedIndex].value;">
			<?php 
				if ($_GET[bid] != ''){
					echo "<option value='$_GET[akd]' selected>$_GET[bid]</option>";
				}else{
					echo "<option value='0' selected>- Bidang Studi -</option>";
				}
						$akd = mysql_query("SELECT * FROM mt_bidang_studi");
						while ($a = mysql_fetch_array($akd)){
							echo "<option value='media.php?module=data&bid=$a[nama_bidang_studi]'>$a[nama_bidang_studi]</option>";
						}
					 
			echo "</select>";
			
			?>
			<select style=' margin-right:3px; margin-bottom:5px; width:130px' ONCHANGE="location = this.options[this.selectedIndex].value;">
			<?php 
				if ($_GET[gol] != ''){
					echo "<option value='$_GET[akd]' selected>Golongan $_GET[gol]</option>";
				}else{
					echo "<option value='0' selected>- Golongan -</option>";
				}
						$akd = mysql_query("SELECT * FROM mt_golongan");
						while ($a = mysql_fetch_array($akd)){
							echo "<option value='media.php?module=data&gol=$a[golongan]'>$a[golongan]</option>";
						}
					 
			echo "</select>";
			
			?><select style=' margin-right:3px; margin-bottom:5px; width:140px' ONCHANGE="location = this.options[this.selectedIndex].value;">
			<?php 
				if ($_GET[akd] != ''){
					echo "<option value='$_GET[akd]' selected>$_GET[akd]</option>";
				}else{
					echo "<option value='0' selected>- Akademik -</option>";
				}
						$akd = mysql_query("SELECT * FROM mt_akademik");
						while ($a = mysql_fetch_array($akd)){
							echo "<option value='media.php?module=data&akd=$a[akademik]'>$a[akademik]</option>";
						}
					 
			echo "</select>";
		
			?><select style=' margin-right:3px; margin-bottom:5px;' ONCHANGE="location = this.options[this.selectedIndex].value;">
			<?php 
				if ($_GET[status] != ''){
					echo "<option value='$_GET[data]' selected>Guru $_GET[status]</option>";
				}else{
					echo "<option value='0' selected>- Semua Status Guru -</option>";
				}
						$guru = mysql_query("SELECT * FROM mt_jenis_guru");
						while ($a = mysql_fetch_array($guru)){
							echo "<option value='media.php?module=data&status=$a[jenis_guru]'>Guru $a[jenis_guru]</option>";
						}
					 
			echo "</select>";

		}
		echo "</div>
		<hr>"; 

	
			  
   $p      = new Paging;
    $batas  = 50;
    $posisi = $p->cariPosisi($batas);
	
	if ($_GET[status] != ''){
		$prosedur=mysql_query("SELECT * FROM rb_pendidik a left join rb_sekolah b ON a.id_sekolah=b.NSS where a.status_guru='$_GET[status]' ORDER BY id_pendidik DESC LIMIT $posisi,$batas");
	}elseif ($_GET[data] != ''){
		$prosedur=mysql_query("SELECT * FROM rb_pendidik a left join rb_sekolah b ON a.id_sekolah=b.NSS where a.status='$_GET[data]' ORDER BY id_pendidik DESC LIMIT $posisi,$batas");
	}elseif ($_GET[akd] != ''){
		$prosedur=mysql_query("SELECT * FROM rb_pendidik a left join rb_sekolah b ON a.id_sekolah=b.NSS where a.akademik='$_GET[akd]' ORDER BY id_pendidik DESC LIMIT $posisi,$batas");
	}elseif ($_GET[kec] != ''){
		$prosedur=mysql_query("SELECT * FROM rb_pendidik a left join rb_sekolah b ON a.id_sekolah=b.NSS where a.kecamatan='$_GET[kec]' ORDER BY id_pendidik DESC LIMIT $posisi,$batas");
	}elseif ($_GET[bid] != ''){
		$prosedur=mysql_query("SELECT * FROM rb_pendidik a left join rb_sekolah b ON a.id_sekolah=b.NSS where a.bidang_studi='$_GET[bid]' ORDER BY id_pendidik DESC LIMIT $posisi,$batas");
	}elseif ($_GET[gol] != ''){
		$prosedur=mysql_query("SELECT * FROM rb_pendidik a left join rb_sekolah b ON a.id_sekolah=b.NSS where a.pangkat_gol='$_GET[gol]' ORDER BY id_pendidik DESC LIMIT $posisi,$batas");
	}elseif ($_GET[jen] != '' AND $_GET[guru] != ''){
		$prosedur=mysql_query("SELECT * FROM rb_pendidik a left join rb_sekolah b ON a.id_sekolah=b.NSS where b.jenjang_sekolah='$_GET[jen]' AND a.status='$_GET[guru]' ORDER BY id_pendidik DESC LIMIT $posisi,$batas");
	}else{
		$prosedur=mysql_query("SELECT * FROM rb_pendidik a left join rb_sekolah b ON a.id_sekolah AND b.jenjang_sekolah ORDER BY id_pendidik DESC LIMIT $posisi,$batas");
	   // SELECT * FROM rb_pendidik a left join rb_sekolah b ON a.id_sekolah AND b.jenjang_sekolah ORDER BY id_pendidik
	    
	}
	
	

  $no = $posisi+1;
  echo "<table style='border:1px solid #c1c1c1;' class='table table-bordered'>
		<tr>
			<th>No</th>
			<th>Nama</th>
			<th>NIP</th>
			<th>Golongan</th>
			<th>Jenis Kelamin</th>
			<th>Bidang Studi</th>
			<th>Akademik</th>
			<th>Action</th>
		</tr>";

  while($r=mysql_fetch_array($prosedur)){
  $tanggal = tgl_indo($r[tgl_daftar]);
  if(($no % 2)==0){ $warna="#fff"; } else{ $warna="#f4f4f4"; }
	echo "<tr bgcolor='$warna'><td>$no</td>
				 <td>$r[nama_lengkap]</td>
				 <td>$r[jika_pns_nip]</td>
				 <td>$r[pangkat_gol]</td>
				 <td>$r[jenis_kelamin]</td>
				 <td>$r[bidang_studi]</td>
				 <td>$r[akademik]</td>
				 <td width='210px'>
				 <a style='padding-bottom:1px; padding-top:1px' class='btn btn-info' title='Lihat Detail Data Pendidik' href='?module=data&act=detaildata&home=$r[id_pendidik]'><i class='icon-search icon-white'></i> Lihat Detail</a>
				 <a style='padding-bottom:1px; padding-top:1px' class='btn btn-danger' title='Hapus Data Pendidik' href='?module=data&act=hapus&id=$r[id_pendidik]'><i class='icon-trash icon-white'></i> Hapus</a></td>
			 </tr>";
	$no++;
  }
  
  if ($_GET[status] != ''){
		$jmldata = mysql_num_rows(mysql_query("SELECT * FROM rb_pendidik where status_guru='$_GET[status]'"));
	}elseif ($_GET[data] != ''){
		$jmldata = mysql_num_rows(mysql_query("SELECT * FROM rb_pendidik where status='$_GET[data]'"));
	}else{
		$jmldata = mysql_num_rows(mysql_query("SELECT * FROM rb_pendidik"));
	}
    $jmlhalaman  = $p->jumlahHalaman($jmldata, $batas);
    $linkHalaman = $p->navHalaman($_GET[halaman], $jmlhalaman);

		echo "</table><br/><hr>";
		echo "</li></ul>
			  <div style='float:left; margin-top:-20px;' class='pagination'>
			  <ul>
				$linkHalaman
			</ul>
		</div>";

    break;

  case "tambahdata":
		include "tambah-pendidik.php";
    break;  

case "hapus":
		mysql_query("DELETE FROM rb_pendidik where id_pendidik='$_GET[id]'");
		echo "<script>window.alert('Sukses Menghapus Data.');
				window.location='media.php?module=data'</script>";
    break; 	
	
  case "excel":
		include "proses_excel.php";
    break; 
    
  case "detaildata":
		include "detail-data-pendidik.php";
    break;  
	
  case "grafik":
		if ($_GET[data] != ''){
			echo "<div class='alert alert-info'>Semua Data $_GET[data] 10 Tahun Terakhir</b>.</div><hr>";
		}else{
			echo "<div class='alert alert-info'>Semua Data Pendidik dan Kependidikan 10 Tahun Terakhir</b>.</div><hr>";
		}
		echo "<div style='float:right;'>";
			?><select style=' margin-right:3px; margin-bottom:5px;' ONCHANGE="location = this.options[this.selectedIndex].value;">
			<?php 
				if ($_GET[data] != ''){
					echo "<option value='$_GET[data]' selected>Semua Data $_GET[data]</option>";
				}else{
					echo "<option value='0' selected>- Pendidik dan Kependidikan -</option>";
				}
				echo "<option value='media.php?module=data&act=grafik&data=pendidik'>Pendidik</option>
				<option value='media.php?module=data&act=grafik&data=kependidikan'>Kependidikan</option>
			</select>
			
		<hr></div>";
		include "diagram-data.php";
	break;
	
	case "jenis":
			echo "<div class='alert alert-info'>Semua Data Pendidik dan Kependidikan 10 Tahun Terakhir</b>.</div><hr>";
		include "diagram-jenis.php";
	break;
}
?>
