﻿<?php 
include "../library/headerdisdik.php";
?>
<!-- /. NAV SIDE  -->
<div id="page-wrapper" >
    <div id="page-inner">
        <div class="row">
            <div class="col-md-12">
             <h2>Blank Page</h2>   
             <h5>Welcome Jhon Deo , Love to see you back. </h5>

         </div>
     </div>
     <!-- /. ROW  -->
     <hr />

 </div> 

<?php
    include "../library/footerdisdik.php";
?>      