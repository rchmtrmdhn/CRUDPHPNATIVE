<?php
	session_start();
	error_reporting(E_ALL ^ E_NOTICE);

	$host_db = "localhost";
	$user_db = "root";
	$pass_db = "";
	$name_db = "tendikdisdik_dec19";

	$con = mysqli_connect($host_db,$user_db,$pass_db,$name_db);
?>