<?php 
include 'koneksi.php';
include "library/header.php";
?>
        <style type="text/css">
    body{
      font-family: comic sans ms;
    }
  </style>
                <div class="col-lg-12 text-center">
                    <!-- start content -->
                    
                    <font color="335EFF"><h2> Inventaris User </h2></font>
                    <hr>
                                
            
              <?php
              $sql="SELECT * FROM `dt_user`";            

              $query = mysqli_query($con,$sql) or die(mysqli_error($con));
              $jumlah = mysqli_num_rows($query);

              if($jumlah==0){
                echo "Data Tidak ada";
              }else{
                ?>
                <br>

                <center>
                  <table id="example" class="table table-striped table-bordered" style="width:100%">
                  <thead>                                    
                    <tr>
                      <th>No.</th>
                      <th>No. Meja</th>
                      <th>Nama Pengguna</th>
                      <th>Departemen</th>
                      <th>Jabatan</th>
                      <th>Perangkat</th>
                      <th>Windows</th>
                      <th>Ms. Office</th>
                      <th>Host Name</th>
                      <th>MAC Address</th>                    
                      <th>Aplikasi</th>                                      
                    </tr>
                    </thead>
                    
                    <?php
                    $no = 1;
                    while($hasil = mysqli_fetch_object($query)){
                      ?>
                    
                      <tr>
                        <td><?php echo $no?></td>
                        <td><?php echo $hasil->no_id ?></td>
                        <td><?php echo $hasil->username ?></td>
                        <td><?php echo $hasil->dept ?></td>
                        <td><?php echo $hasil->jabatan ?></td>
                        <td><?php echo $hasil->perangkat ?></td>
                        <td><?php echo $hasil->windows ?></td>
                        <td><?php echo $hasil->office ?></td>
                        <td><?php echo $hasil->host ?></td>
                        <td><?php echo $hasil->mac ?></td>                                                
                        <td><?php echo $hasil->aplikasi ?></td>                                                
                      </tr>
                    
                      <?php 
                      $no++;
                    } ?>
                    <tfoot>                                        
                    <tr>
                      <th>No.</th>
                      <th>No. Meja</th>
                      <th>Nama Pengguna</th>
                      <th>Departemen</th>
                      <th>Jabatan</th>
                      <th>Perangkat</th>
                      <th>Windows</th>
                      <th>Ms. Office</th>
                      <th>Host Name</th>
                      <th>MAC Address</th>                    
                      <th>Aplikasi</th>                                        
                    </tr>
                    </tfoot>
                  </table>
                  <?php } ?>

        </div>
    </div>
</div>


        
<?php
    include "library/footer.php";
?>      