<?php 
include "../koneksi.php";
session_start();
if(isset($_SESSION['admin'])) {
  include('../library/headerdisdik.php');
}else{
  include ('../library/header.php');
}

?>?>
<?php 

if(empty($_SESSION["admin"])){
  header("location:../index.php");
} 
?>
<div id="page-wrapper" >
  <div id="page-inner">
    <div class="row">
      <div class="col-md-12">
       <h2>Daftar Agenda</h2>                          
       <?php
       if(!empty($_GET["salah"])){
        echo $_GET["salah"];
      }
      ?>
      <!-- /. ROW  -->
      <hr />
      <div class="row">
        <!-- start content -->

        <center>
          <form method="get" action="daftaragenda.php">
            <input type="text" name="cari" placeholder="Cari Agenda">
            <button type="submit" class="btn btn-success">Cari</button>
          </form>
        </center>
        <?php
        if(!empty($_GET["cari"])){
          $sql="SELECT * FROM `rb_agenda` WHERE `txt_np` LIKE '%".$_GET["cari"]."%'";
        }else{
          $sql="SELECT * FROM `rb_agenda`";
        }

        $query = mysqli_query($con,$sql) or die(mysqli_error($con));
        $jumlah = mysqli_num_rows($query);

        if($jumlah==0){
          echo "Data Tidak ada";
        }else{
          ?>
          <br>
          <center>
            <table border="1" class="table table-bordered" id="example" width="80%" >
              <thead>
                <tr>
                  <th>No.</th>
                  <th>Nomor Proyek</th>
                  <th>NIK</th>
                  <th>Nama Lengkap</th>
                  <th>Keterangan</th>
                  <th>Tanggal Mulai</th>
                  <th>Tanggal Berakhir</th>
                </tr>
              </thead>
              <?php
              $no = 1;
              while($hasil = mysqli_fetch_object($query)){
                ?>
                <tfoot>
                  <tr>
                    <td><?php echo $no?></td>
                    <td><?php echo $hasil->np ?></td>
                    <td><?php echo $hasil->nik ?></td>
                    <td><?php echo $hasil->pic ?></td>
                    <td><?php echo $hasil->keterangan ?></td>
                    <td><?php echo $hasil->tanggal_mulai ?></td>
                    <td><?php echo $hasil->tanggal_berakhir ?></td>
                    <td><a class="btn btn-primary" href="lihatagenda.php?id=<?php echo $hasil->np?>"><span class="fa fa-file"></span></a></td>
                    <td><a class="btn btn-info" href="editagenda.php?id=<?php echo $hasil->np?>"><span class="fa fa-edit"></span></a></td>
                    <td><a class="btn btn-danger" href="proses/do_hapus_agenda.php?id=<?php echo $hasil->id_agenda?>" onclick="return confirm('Anda yakin mau hapus <?php echo $hasil->keterangan?> ?')"><span class="fa fa-trash"></span></a></td>
                  </tr>
                  <?php 
                  $no++;
                } ?>
              </tfoot>
            </table>
          <?php } ?>
        </center>
        <br><br><br><br>
      </div>
    </div>       
  </div>    
  <!-- end content -->
</div>
<!-- /. PAGE WRAPPER  -->
<?php
include "../library/footerdisdik.php";
?>