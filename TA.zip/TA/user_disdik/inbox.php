<?php 
include "../koneksi.php";
session_start();
if(isset($_SESSION['admin'])) {
  include('../library/headerdisdik.php');
}else{
  include ('../library/header.php');
  }
 ?> 

 <?php 
 if(empty($_SESSION["admin"])){
        header("location:../index.php");
    } ?>
<!-- /. NAV SIDE  -->
<div id="page-wrapper" >
    <div id="page-inner">
        <div class="row">
            <div class="col-md-12">
             <h2>Pesan Masuk</h2>                
           </div>
        </div>
     <!-- /. ROW  -->
     <hr>                      
                <?php
                if(!empty($_GET["salah"])){
                  echo $_GET["salah"];
                }               
                ?>                

              <div class="col-md-12">
              <div class="alert info">
                <?php
                  $sql = "SELECT * FROM `rb_hubungi` ";
                  $query = mysqli_query($con,$sql) or die(mysqli_error($con));
                  $jumlah = mysqli_num_rows($query);
                ?>
                <span class="closebtn">&times;</span>  
                Semua <strong>Pesan - <?php echo $jumlah?> Pesan. </strong>
              </div>       
            </div>

            <section id="tabel" >
            <div class="container">
                <div class="row">
                    <div class="col-lg-10 text-center">
                        <div class="section-title">                                               
                                             
              <?php
              
              $sql="SELECT * FROM `rb_hubungi`";            
              $query = mysqli_query($con,$sql) or die(mysqli_error($con));
              $jumlah = mysqli_num_rows($query);

              if($jumlah==0){
                echo "Data Tidak ada";
              }else{
                ?>                

                      <center>
                        <table id="example" class="table table-bordered" style="width:100%">
                        <thead>                                    
                          <tr>
                            <th>No.</th>                               
                            <th>Nama Pengirim</th>
                            <th>Email</th> 
                            <th>Pesan</th>                                                        
                            <th>Tanggal</th>                            
                            <th>Action</th>                      
                          </tr>
                          </thead>
                          
                          <?php
                          $no = 1;
                          while($hasil = mysqli_fetch_object($query)){
                            ?>
                          
                            <tr>
                              <td><?php echo $no?></td>                              
                              <td><?php echo $hasil->nama ?></td>
                              <td><?php echo $hasil->email ?></td>
                              <td><?php echo $hasil->pesan ?></td>
                              <td><?php echo $hasil->tanggal ?></td>
                              <td colspan="3"><a class="btn btn-primary" href="cekinbox.php?id=<?php echo $hasil->id_hubungi?>"> <span class="fa fa-search"></span></a></td>
                            </tr>
                          
                            <?php 
                            $no++;
                          } ?>
                          <tfoot>                                        
                          <tr>
                            <th>No.</th>                      
                            <th>Nama Pengirim</th>
                            <th>Email</th> 
                            <th>Pesan</th>                                                        
                            <th>Tanggal</th>                            
                            <th>Action</th>                                                               
                          </tr>
                          </tfoot>
                        </table>
                        <?php } ?>
                  
                        </div>
                    </div>
                </div>
                
            </div>
            <!-- /.container -->
        </section>

 </div> 

<?php
    include "../library/footerdisdik.php";
?>      