<?php 
include "../koneksi.php";
session_start();
if(isset($_SESSION['admin'])) {
	include('../library/headerdisdik.php');
}else{
	include ('../library/header.php');
}
?> 

<?php 
if(empty($_SESSION["admin"])){
	header("location:../index.php");
} 
?>
<!-- /. NAV SIDE  -->
<div id="page-wrapper" >
	<div id="page-inner">
		<div class="row">
			<div class="col-md-12">

				<h2> Profil </h2>
				<hr>

				<?php
				$id = $_GET['id'];
				$sql="SELECT * FROM `rb_users` WHERE `id_user` ='".$id."' ";			

				$query = mysqli_query($con,$sql) or die(mysqli_error($con));
				$jumlah = mysqli_num_rows($query);

				if($jumlah==0){
					echo "Data Tidak ada";
				}else{
					?>


					<?php
					while($hasil = mysqli_fetch_object($query)){
						?>
						<fieldset>

							<table>
								<tr>			 			 				 	
									<td><img src="../img/<?php echo $hasil->foto?>" width="150" height="150"></td>
								</tr>
							</table>
							<br>
							<table class="table">
								<tr>
									<th>Email</th>
									<th>:</th>
									<td><?php echo $hasil->aemail ?></td>
								</tr>
								<tr>
									<th>Nama Lengkap</th>
									<th>:</th>
									<td><?php echo $hasil->nama_lengkap ?></td>
								</tr>

								<tr>
									<th>Jenis Kelamin</th>
									<th>:</th>
									<td><?php echo $hasil->jenis_kelamin  ?></td>
								</tr>
								<tr>
									<th>Level</th>
									<th>:</th>
									<td><?php echo $hasil->level  ?></td>
								</tr>			 	
								<tr>
									<td colspan="3"><a class="btn btn-primary" href="ubah_user_sekolah.php?id=<?php echo $hasil->id_user?>"><span class="fa fa-pencil"></span></a></td>	
								</tr>
							</table>
							<?php 
							$no++;
						} ?>


					<?php } ?>
					
				</fieldset>

			</div>	
		</div>
	</div>
</div>		

<?php  
include "../library/footerdisdik.php";
?> 		
