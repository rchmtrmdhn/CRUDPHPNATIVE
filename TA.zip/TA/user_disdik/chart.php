<?php 
include "../koneksi.php";
session_start();
if(isset($_SESSION['admin'])) {
  include('../library/headerdisdik.php');
}else{
  include ('../library/header.php');
}
?> 

<?php 
if(empty($_SESSION["admin"])){
  header("location:../index.php");
}
$sql2 = "SELECT * FROM `rb_pendidik` WHERE `status`='pendidik'";
$sql3 = "SELECT * FROM `rb_pendidik` WHERE `status`='kependidikan'";
?>
<!-- /. NAV SIDE  -->
<div id="page-wrapper" >
  <div id="page-inner">
    <div class="row">
      <div class="col-md-12">
        <h2>Charts</h2>                           
        <!-- /. ROW  -->
        <hr>     
        <div class="row">
          <div style="width: 800px;margin: 0px auto;">
            <canvas id="myChart"></canvas>
          </div>              
        </div>  
        <hr>
        
      </div>               

    </div> 
    <!-- /. PAGE INNER  -->
  </div>
  <!-- /. PAGE WRAPPER  -->
</div>
<!-- /. WRAPPER  -->  
<?php
include "../library/footerdisdik.php";
?>      