<?php 
include "../koneksi.php";
session_start();
if(isset($_SESSION['admin'])) {
  include('../library/headerdisdik.php');
}else{
  include ('../library/header.php');
  }
 ?> 

 <?php 
 if(empty($_SESSION["admin"])){
        header("location:../index.php");
    } ?>
<!-- /. NAV SIDE  -->
<div id="page-wrapper" >
    <div id="page-inner">
        <div class="row">
            <div class="col-md-12">
             <h2>Lihat Pesan</h2>                
           </div>
        </div>
     <!-- /. ROW  -->
     <hr>         

     <form method="post" action="proses/do_cekinbox.php?id=<?php echo $id?>" enctype="multipart/form-data">

    <?php
    $id = $_GET["id"];      
    $sql = "SELECT * FROM `rb_hubungi` WHERE `id_hubungi`='".$id."'";
    $query = mysqli_query($con,$sql) or die (mysqli_error($con));
    $hasil = mysqli_fetch_object($query);
     ?>
     <fieldset>
      
        <?php
        if(!empty($_GET["salah"])){
          echo $_GET["salah"];
        }
        ?>       

        <table class="">
          <tr>            
          <tr>
            <th>Nama Pengirim</th>
          </tr>  
              <td><input type="text" name="txt_nama" value="<?php echo $hasil->nama?>" class="form-control input-md"> </td>
          </tr>
          <tr>            
                                
        </table>
        
        <table class="">
         <tr>
          <tr>
            <th>Email</th>
          </tr>  
            <td><input type="text" name="mac" value="<?php echo $hasil->email?>" class="form-control input-md"> </td>
          </tr>
        </table>

         <table class="">
         <tr>
          <tr>
            <th>Tanggal Diterima</th>
          </tr>  
            <td><input type="text" name="mac" value="<?php echo $hasil->tanggal?>" class="form-control input-md"> </td>
          </tr>
        </table>

        <br>
        <table class="">
          <tr>
            <td>
              <td><textarea cols="140" name="txt_pesan" rows="15"><?php echo $hasil->pesan  ?></textarea>
            </td>
          </tr>
        </table>        
      </fieldset>
      <!-- end content -->
    </div>
    <!-- end row middle -->
  </div>
</div>
</body>
</form>
              

 </div> 

<?php
    include "../library/footerdisdik.php";
?>      