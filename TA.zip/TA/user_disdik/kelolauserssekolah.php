<?php 
include "../koneksi.php";
include "../library/headerdisdik.php";
?>
<!-- /. NAV SIDE  -->
<div id="page-wrapper" >
    <div id="page-inner">
        <div class="row">
            <div class="col-md-12">
             <h2>Users Sekolah</h2>                   
            </div>
        </div>
     <!-- /. ROW  -->
     <hr>
              <!-- BUTTON  -->
              <div class="col-md-6 col-sm-6 col-xs-6"> 
                <a class="btn btn-success" href="#">Print Semua Data</a>                
                  <div class="col-md-7 col-sm-6 col-xs-6">
                    <a class="btn btn-primary" href="register/registersekolah.php">Tambah Data</a>                        
                  </div>                                                                      
              </div><br><br><br>     
              <!-- END BUTTON -->

              <!-- alert -->
              <div class="col-md-12">
              <div class="alert info">
                <?php
                  $sql = "SELECT * FROM `rb_users` WHERE `level` like 'sekolah' ";
                  $query = mysqli_query($con,$sql) or die(mysqli_error($con));
                  $jumlah = mysqli_num_rows($query);
                ?>
                <span class="closebtn">&times;</span>  
                Semua Data <strong>Users Sekolah - <?php echo $jumlah?> Orang. </strong>
              </div>     
              </div>
                                             
                <?php
              
              $sql = "SELECT * FROM `rb_users` WHERE `level` like 'sekolah' ";
              $query = mysqli_query($con,$sql) or die(mysqli_error($con));
              $jumlah = mysqli_num_rows($query);

              if($jumlah==0){
                echo "Data Tidak ada";
              }else{
                ?>                

                <center>
                  <table id="example" class="table table-bordered" style="width:100%">
                  <thead>                                    
                    <tr>
                      <th><center>No.</th>
                      <th><center>Nama</th>                      
                      <th><center>Username/Email</th>   
                      <th><center>Level</th>                                                                                  
                      <th><center>Aksi</th>                                                                                  
                    </tr>                    
                    </thead>
                    
                    <?php
                    $no = 1;
                    while($hasil = mysqli_fetch_object($query)){
                      ?>
                    
                      <tr align="center">
                        <td><?php echo $no?></td>
                        <td><?php echo $hasil->nama_lengkap ?></td>
                        <td><?php echo $hasil->aemail ?></td>                                                                
                        <td><?php echo $hasil->level ?></td>                        
                        <td>
                          <a class="btn btn-primary" href="profil_user_sekolah.php?id=<?php echo $hasil->id_user?>"><span class="fa fa-pencil"></span></a>                                                                                            
                        
                          <a class="btn btn-danger" href="proses/do_hapussekolah.php?id=<?php echo $hasil->aemail?>" onclick="return confirm('Anda yakin mau hapus <?php echo $hasil->aemail?> ?')"><span class="fa fa-trash"></span></a>
                        </td>
                      </tr>
                    
                      <?php 
                      $no++;
                    } ?>
                    <tfoot>                                        
                    <tr>
                      <th><center>No.</th>
                      <th><center>Nama</th>                      
                      <th><center>Username/Email</th>   
                      <th><center>Level</th>                                                                                  
                      <th><center>Aksi</th>                                                                                  
                    </tr>
                    </tfoot>
                  </table>
                  <?php } ?>
                  
                        </div>
                    </div>
                </div>
                
            </div>
            <!-- /.container -->

 </div> 

<?php
    include "../library/footerdisdik.php";
?>      