<?php 
include "../koneksi.php";
include "../library/headerdisdik.php";
?>
<!-- /. NAV SIDE  -->
<div id="page-wrapper" >
    <div id="page-inner">
        <div class="row">
            <div class="col-md-12">
             <h2>Data Pendidik & Kependidikan</h2>                
           </div>
        </div>
     <!-- /. ROW  -->
     <hr>    
              <!-- BUTTON  -->
              <div class="col-md-6 col-sm-6 col-xs-6"> 
                <a class="btn btn-success" href="#">Print Semua Data</a>                
                  <div class="col-md-7 col-sm-6 col-xs-6">
                    <a class="btn btn-primary" href="registerpendidik.php">Tambah Data</a>                                               
                  </div>                                                                      
              </div><br><br><br>     
              <!-- END BUTTON -->

              <!-- alert -->
              <div class="col-md-12">
              <div class="alert info">
                <?php
                  $sql = "SELECT * FROM `rb_pendidik` ";         
                  $query = mysqli_query($con,$sql) or die(mysqli_error($con));
                  $jumlah = mysqli_num_rows($query);
                ?>
                <span class="closebtn">&times;</span>  
                Semua Data <strong>Pendidik & Kependidikan - <?php echo $jumlah?> Orang. </strong>
              </div>     
            </div>
                                             
                <?php
              
              $sql = "SELECT * FROM `rb_pendidik` ";         
              $query = mysqli_query($con,$sql) or die(mysqli_error($con));
              $jumlah = mysqli_num_rows($query);

              if($jumlah==0){
                echo "Data Tidak ada";
              }else{
                ?>                

               <center>
                        <table id="example" class="table table-bordered" style="width:100%">
                        <thead>                                    
                          <tr>
                            <th>No.</th>                      
                            <th>Nama</th>
                            <th>NIP</th>
                            <th>Golongan</th>
                            <th>Jenis Kelamin</th>
                            <th>Bidang Studi</th>
                            <th>Akademik</th>
                            <th>Action</th>                      
                          </tr>
                          </thead>
                          
                          <?php
                          $no = 1;
                          while($hasil = mysqli_fetch_object($query)){
                            ?>
                          
                            <tr>
                              <td><?php echo $no?></td>
                              <td><?php echo $hasil->nama_lengkap ?></td>
                              <td><?php echo $hasil->jika_pns_nip ?></td>
                              <td><?php echo $hasil->pangkat_gol ?></td>
                              <td><?php echo $hasil->jenis_kelamin ?></td>
                              <td><?php echo $hasil->bidang_studi ?></td>
                              <td><?php echo $hasil->akademik ?></td>
                              <td>lihat</td>                        
                            </tr>
                          
                            <?php 
                            $no++;
                          } ?>
                          <tfoot>                                        
                          <tr>
                            <th>No.</th>                      
                            <th>Nama</th>
                            <th>NIP</th>
                            <th>Golongan</th>
                            <th>Jenis Kelamin</th>
                            <th>Bidang Studi</th>
                            <th>Akademik</th>
                            <th>Action</th>                                                               
                          </tr>
                          </tfoot>
                        </table>
                        <?php } ?>
                  
                        </div>
                    </div>
                </div>
                
            </div>
            <!-- /.container -->        

 </div> 

<?php
    include "../library/footerdisdik.php";
?>      