<?php 
include "../koneksi.php";
session_start();
if(isset($_SESSION['admin'])) {
  include('../library/headerdisdik.php');
}else{
  include ('../library/header.php');
}

?>
<?php 

if(empty($_SESSION["admin"])){
  header("location:../kelolagenda.php");
} 
?>
<!-- /. NAV SIDE  -->
<div id="page-wrapper" >
 <div id="page-inner">
  <div class="row">


    <div class="col-md-12">

      <br><br>
      <!-- Form Name -->
      <legend>Edit Data Agenda</legend>
      <?php
      $id = $_GET["id"];
      $sql = "SELECT * FROM `rb_agenda` WHERE `np`='".$id."'";
      $query = mysqli_query($con,$sql) or die (mysqli_error($con));
      $hasil = mysqli_fetch_object($query);
      ?>

      <form method="post" action="proses/do_editagenda.php?id=<?php echo $id?>" class="form-horizontal" enctype="multipart/form-data">
        <?php
        if(!empty($_GET["salah"])){
          echo $_GET["salah"];
        }
        ?>
        <!-- Name input-->
        <div class="form-group">
          <label class="col-md-4 control-label" for="txt_np">Nomor Proyek</label>
          <div class="col-md-4">
           <input id="txt_np" name="txt_np" type="text" value="<?php echo $hasil->np ?>" class="form-control input-md">
         </div>
       </div>
       <!-- Name input-->
       <div class="form-group">
        <label class="col-md-4 control-label" for="txt_nik">NIK PIC</label>
        <div class="col-md-4">
         <input id="txt_nik" name="txt_nik" type="text" value="<?php echo $hasil->nik ?>" class="form-control input-md">
       </div>
     </div>

     <!-- Name input-->
     <div class="form-group">
      <label class="col-md-4 control-label" for="txt_pic">PIC</label>
      <div class="col-md-4">
        <input id="txt_pic" name="txt_pic" type="text" value="<?php echo $hasil->pic ?>" class="form-control input-md">
      </div>
    </div>

    <!-- Name input-->
    <div class="form-group">
      <label class="col-md-4 control-label" for="txt_keterangan">Keterangan</label>
      <div class="col-md-4">
        <input id="txt_keterangan" name="txt_keterangan" type="text" value="<?php echo $hasil->keterangan ?>" class="form-control input-md">
      </div>
    </div>

    <!-- File Button -->
    <label class="col-md-4 control-label" for="btn_file">Dokumen Pendukung</label>
    <div class="form-group">
      <label class="col-md-4 control-label" for="btn_file"></label>
      <div class="col-md-4">
        Dokumen 1
        <br>
        <a href="../img/<?php echo $hasil->file1?>"><?php echo $hasil->file1 ?></a>
        <input id="btn_file1" name="btn_file1" class="input-file" type="file">
        Dokumen 2
        <br>
        <a href="../img/<?php echo $hasil->file1?>"><?php echo $hasil->file2 ?></a>
        <input id="btn_file1" name="btn_file2" class="input-file" type="file">
        Dokumen 3
        <br>
        <a href="../img/<?php echo $hasil->file1?>"><?php echo $hasil->file3 ?></a>
        <input id="btn_file1" name="btn_file3" class="input-file" type="file">
        Dokumen 4
        <br>
        <a href="../img/<?php echo $hasil->file1?>"><?php echo $hasil->file4 ?></a>
        <input id="btn_file1" name="btn_file4" class="input-file" type="file">
      </div>
    </div>

    <!-- Radio Button -->
    <div class="form-group">
      <label class="col-md-4 control-label" for="">Tanggal Mulai</label>
      <div class="col-md-4">                     
        <?php
        $lahir = explode("-", $hasil->tanggal_mulai);
        ?>
        <select name="cbo_tgl">
          <option value="">-Tgl-</option>
          <?php
          for($i=1; $i<=31; $i++){
            ?>
            <option value="<?php echo $i?>" <?php if($lahir[2]==$i){ ?> selected <?php }?>>
              <?php echo $i?>
            </option>
            <?php
          }
          ?>  
        </select>
        <select name="cbo_bln">
          <option value="">-Bln-</option>
          <?php
          $b =1;
          while($b<=12){
            ?>
            <option value="<?php echo $b?>" <?php if($lahir[1]==$b){ ?> selected <?php }?>>
              <?php echo $b?>
            </option>
            <?php
            $b++; 
          }
          ?>
        </select>
        <select name="cbo_thn">
          <option value="">-Thn-</option>
          <?php
          $t=1970;
          do{
            ?>
            <option value="<?php echo $t?>" <?php if($lahir[0]==$t){ ?> selected <?php }?>>
              <?php echo $t?>
            </option>
            <?php
            $t++;
          }while($t<=date("Y"));
          ?>
        </select>
      </div>
    </div>
    <!-- Radio Button -->
    <div class="form-group">
      <label class="col-md-4 control-label" for="">Tanggal Berakhir</label>
      <div class="col-md-4">
        <?php
        $lahir2 = explode("-", $hasil->tanggal_berakhir);
        ?>
        <select name="cbo_tgl2">
          <option value="">-Tgl-</option>
          <?php
          for($i=1; $i<=31; $i++){
            ?>
            <option value="<?php echo $i?>" <?php if($lahir2[2]==$i){ ?> selected <?php }?>>
              <?php echo $i?>
            </option>
            <?php
          }
          ?>  
        </select>
        <select name="cbo_bln2">
          <option value="">-Bln-</option>
          <?php
          $b =1;
          while($b<=12){
            ?>
            <option value="<?php echo $b?>" <?php if($lahir2[1]==$b){ ?> selected <?php }?>>
              <?php echo $b?>
            </option>
            <?php
            $b++; 
          }
          ?>
        </select>
        <select name="cbo_thn2">
          <option value="">-Thn-</option>
          <?php
          $t=1970;
          do{
            ?>
            <option value="<?php echo $t?>" <?php if($lahir2[0]==$t){ ?> selected <?php }?>>
              <?php echo $t?>
            </option>
            <?php
            $t++;
          }while($t<=date("Y"));
          ?>
        </select>
      </div>
    </div>
    <!-- Button -->
    <div class="form-group">
      <label class="col-md-6 control-label" for="btn_upload"></label>
      <div class="col-md-4" >
       <button id="btn_upload" name="btn_upload" class="btn btn-success">Ubah Data</button>
     </div>
   </div>
 </div>
</form>
</div>	
</div>
</div>

<?php  
include "../library/footerdisdik.php";
?> 		