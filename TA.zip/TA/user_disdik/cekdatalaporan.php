<?php 
include "../koneksi.php";
session_start();
if(isset($_SESSION['admin'])) {
  include('../library/headerdisdik.php');
}else{
  include ('../library/header.php');
}
?> 

<?php 
if(empty($_SESSION["admin"])){
  header("location:../index.php");
} 
?>
<!-- /. NAV SIDE  -->
<div id="page-wrapper" >
  <div id="page-inner">
    <div class="row">
      <div class="col-md-12">
       <h2>Cek Data Agenda</h2>   
       <section id="tabel" >
        <div class="container">
          <div class="row">
            <div class="col-lg-10 text-center">
              <div class="section-title">                  <?php
              if(!empty($_GET["salah"])){
                echo $_GET["salah"];
              }
              ?>                             

              <?php

              $sql="SELECT * FROM `rb_laporan`";            
              $query = mysqli_query($con,$sql) or die(mysqli_error($con));
              $jumlah = mysqli_num_rows($query);

              if($jumlah==0){
                echo "Data Tidak ada";
              }else{
                ?>                

                <center>
                  <table id="example" class="table table-bordered" style="width:100%">
                    <thead>                                    
                      <tr>
                        <th>No</th>
                        <th>Nomor Proyek</th>
                        <th>Tanggal Kirim Laporan</th>
                        <th>File 1</th>
                        <th>File 2</th>
                        <th>File 3</th>
                        <th>File 4</th>
                      </tr>
                    </thead>

                    <?php
                    $no = 1;
                    while($hasil = mysqli_fetch_object($query)){
                      ?>

                      <tr>
                        <td><?php echo $no?></td>
                        <td><?php echo $hasil->np ?></td>
                        <td><?php echo $hasil->tanggal ?></td>
                        <td><?php echo $hasil->selesai1 ?></td>
                        <td><?php echo $hasil->selesai2 ?></td>
                        <td><?php echo $hasil->selesai3 ?></td>
                        <td><?php echo $hasil->selesai4 ?></td>
                        <td><a class="btn btn-primary" href="ceklaporan.php?id=<?php echo $hasil->id_laporan?>"><span class="fa fa-check"></span></a></td>
                      </tr>
                      <?php 
                      $no++;
                    } ?>
                    <tfoot>                                        
                      <tr>
                        <th>No</th>
                        <th>Nomor Proyek</th>
                        <th>Tanggal Kirim Laporan</th>
                        <th>File 1</th>
                        <th>File 2</th>
                        <th>File 3</th>
                        <th>File 4</th>
                      </tr>
                    </tfoot>
                  </table>
                <?php } ?>

              </div>
            </div>
          </div>

        </div>
        <!-- /.container -->
      </section>

    </div> 

    <?php
    include "../library/footerdisdik.php";
    ?>      