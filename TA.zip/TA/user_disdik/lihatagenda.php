<?php 
include "../koneksi.php";
session_start();
if(isset($_SESSION['admin'])) {
  include('../library/headerdisdik.php');
}else{
  include ('../library/header.php');
}

?>
<?php 

if(empty($_SESSION["admin"])){
  header("location:../kelolagenda.php");
} 
?>
<!-- /. NAV SIDE  -->
<div id="page-wrapper" >
 <div id="page-inner">
  <div class="row">

    <form method="post" action="proses/do_agenda.php" class="form-horizontal" enctype="multipart/form-data">
      <div class="col-md-12">

        <br><br>
        <!-- Form Name -->
        <legend>Data Agenda</legend>
        <?php
        $id = $_GET["id"];
        $sql = "SELECT * FROM `rb_agenda` WHERE `np`='".$id."'";
        $query = mysqli_query($con,$sql) or die (mysqli_error($con));
        $hasil = mysqli_fetch_object($query);
        ?>
        <!-- Name input-->
        <div class="form-group">
          <label class="col-md-4 control-label" for="txt_np">Nomor Proyek</label>
          <div class="col-md-4">
           <input id="txt_np" name="txt_np" type="text" value="<?php echo $hasil->np ?>" disabled class="form-control input-md">
         </div>
       </div>
        <!-- Name input-->
        <div class="form-group">
          <label class="col-md-4 control-label" for="txt_nik">NIK PIC</label>
          <div class="col-md-4">
           <input id="txt_nik" name="txt_nik" type="text" value="<?php echo $hasil->nik ?>" disabled class="form-control input-md">
         </div>
       </div>

       <!-- Name input-->
       <div class="form-group">
        <label class="col-md-4 control-label" for="txt_pic">PIC</label>
        <div class="col-md-4">
          <input id="txt_pic" name="txt_pic" type="text" value="<?php echo $hasil->pic ?>" disabled class="form-control input-md">
        </div>
      </div>

      <!-- Name input-->
      <div class="form-group">
        <label class="col-md-4 control-label" for="txt_keterangan">Keterangan</label>
        <div class="col-md-4">
          <input id="txt_keterangan" name="txt_keterangan" type="text" value="<?php echo $hasil->keterangan ?>" disabled class="form-control input-md">
        </div>
      </div>

      <!-- File Button -->
      <label class="col-md-4 control-label" for="txt_keterangan">Dokumen Pendukung</label>
      <div class="form-group">
        <label class="col-md-4 control-label" for="btn_file"></label>
        <div class="col-md-4">
          Dokumen 1
          <br>
          <a href="../img/<?php echo $hasil->file1?>"><?php echo $hasil->file1 ?></a>
          <br>
          Dokumen 2
          <br>
          <a href="../img/<?php echo $hasil->file1?>"><?php echo $hasil->file2 ?></a>
          <br>
          Dokumen 3
          <br>
          <a href="../img/<?php echo $hasil->file1?>"><?php echo $hasil->file3 ?></a>
          <br>
          Dokumen 4
          <br>
          <a href="../img/<?php echo $hasil->file1?>"><?php echo $hasil->file4 ?></a>
        </div>
      </div>

      <!-- Radio Button -->
      <div class="form-group">
        <label class="col-md-4 control-label" for="">Tanggal Mulai</label>
        <div class="col-md-4">                     
          <input id="txt_keterangan" name="txt_keterangan" type="text" value="<?php echo $hasil->tanggal_mulai ?>" disabled class="form-control input-md">
        </div>
      </div>
      <!-- Radio Button -->
      <div class="form-group">
        <label class="col-md-4 control-label" for="">Tanggal Berakhir</label>
        <div class="col-md-4">
          <input id="txt_keterangan" name="txt_keterangan" type="text" value="<?php echo $hasil->tanggal_berakhir ?>" disabled class="form-control input-md">
        </div>
      </div>
    </div>	
  </form>
</div>	
</div>
</div>

<?php  
include "../library/footerdisdik.php";
?> 		