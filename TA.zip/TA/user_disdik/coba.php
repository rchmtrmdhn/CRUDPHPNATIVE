<?php 
include "../koneksi.php";
session_start();
if(isset($_SESSION['admin'])) {
  include('../library/headerdisdik.php');
}else{
  include ('../library/header.php');
  }
 ?> 

<?php 
 if(empty($_SESSION["admin"])){
    header("location:../index.php");
  } 
  ?>
  <!-- /. NAV SIDE  -->
  <div id="page-wrapper" >
    <div id="page-inner">
      <div class="row">

       <form method="post" action="proses/do_registerpendidik.php" enctype="multipart/form-data">
               <?php
                if(!empty($_GET["salah"])){
                  echo $_GET["salah"];
                }

               
                $id = $_GET["id"];
                $sql = "SELECT * FROM `rb_pendidik` WHERE `id_pendidik`='".$id."'";
                $query = mysqli_query($con,$sql) or die (mysqli_error($con));
                $hasil = mysqli_fetch_object($query);
                $sql2 = "SELECT * FROM `rb_pendidik`";
                $query2 = mysqli_query($con,$sql2) or die (mysqli_error($con));
                $hasil2 = mysqli_fetch_object($query2);
                #ambil data sekolah
                $query3 = "SELECT id_sekolah, nama_sekolah FROM mt_sekolah ORDER BY nama_sekolah";
                $sql3 = mysqli_query($con, $query3);
                $arrmt_sekolah = array();
                while ($row = mysqli_fetch_assoc($sql3)) {
                  $arrmt_sekolah [ $row['id_sekolah'] ] = $row['nama_sekolah'];
                }
    
                ?>

                <form class="form-horizontal">
                  <fieldset>
                    <div class="col-md-12">
                      <div class="alert info">                                                
                        <strong> 1. Identitas Sekolah</strong>
                      </div><br>      
                    </div><br><br><br><br><br>
  <!-- select -->
                  <div class="form-group">
                    <label class="col-md-2 control-label" for="id_sekolah">Nama Sekolah</label>
                                           
                    <div class="col-md-3">
                      <span class="inputan">
                        <select id="nama_sekolah" name="id_sekolah">
                          <option value=""><?php echo $hasil->id_sekolah?></option>
                          <?php
                          foreach ($arrmt_sekolah as $id_sekolah=>$nama_sekolah) {
                            echo "<option value='$nama_sekolah'>$nama_sekolah</option>";
                          }
                          ?>
                        </select>
                      </span>
                    </div><br>
                  </div><br>                                            

                   <div class="col-md-12">
                      <div class="alert info">                                                
                        <strong> 2. Identitas Pendidik dan Tenaga Kependidikan</strong>
                      </div><br>      
                    </div><br><br><br><br><br>               

                    <!-- Text input-->
                    <div class="form-group">
                      <label class="col-md-2 control-label" for="nama_lengkap">Nama Lengkap</label>                      
                      <div class="col-md-4">
                        <input value="<?php echo $hasil->nama_lengkap?>" id="nama_lengkap" name="nama_lengkap" type="text" placeholder="Nama Lengkap"  class="form-control input-md">
                      </div><br>
                    </div><br>                    

                    <!-- Text input-->
                    <div class="form-group">
                      <label class="col-md-2 control-label" for="nik"> NIK</label>Wajib, sesuai KTP/KK yang berlaku, PASSPORT untuk WNA                     
                      <div class="col-md-4">
                       <input value="<?php echo $hasil->nik?>" id="nik" name="nik" type="text" placeholder="Nama Lengkap"  class="form-control input-md">
                      </div><br>
                    </div><br>     

                    <!-- select -->
                  <div class="form-group">
                    <label class="col-md-2 control-label" for="jenis_kelamin">Jenis Kelamin</label>                    
                    <div class="col-md-1">                     
                      <select name="jenis_kelamin">
                        <option value=""><?php echo $hasil->jenis_kelamin?></option>
                        <?php 
                        $jenis_kelamin = array("Laki-laki ","Perempuan ");
                        foreach($jenis_kelamin as $j){
                          ?>
                          <option value="<?php echo $j?>">
                            <?php echo $j?>
                          </option>
                          <?php
                        }
                        ?>
                      </select>
                    </div><br>
                  </div><br>       

                  <!-- Text input-->
                    <div class="form-group">
                      <label class="col-md-2 control-label" for="tempat_lahir">Tempat Lahir</label>                      
                      <div class="col-md-4">
                        <input value="<?php echo $hasil->tempat_lahir?>" id="tempat_lahir" name="tempat_lahir" type="text" placeholder="Tempat Lahir"  class="form-control input-md">
                      </div>       

                      <!-- Radio Button -->
                      <div class="form-group">
                        <label class="col-md-1 control-label" for="">Tanggal Lahir</label>                    
                        <div class="col-md-3">                     
                          <?php
                          $lahir = explode("-", $hasil->tgl_lahir);
                          ?>
                          <select name="cbo_tgl1">
                            <option value="">-Tgl-</option>
                            <?php
                            for($i=1; $i<=31; $i++){
                              ?>
                              <option value="<?php echo $i?>" <?php if($lahir[2]==$i){?> selected <?php }?>>
                                <?php echo $i?>
                              </option>
                              <?php
                            }
                            ?>  
                          </select>
                          <select name="cbo_bln1">
                            <option value="">-Bln-</option>
                            <?php
                            $b =1;
                            while($b<=12){
                              ?>
                              <option value="<?php echo $b?>" <?php if($lahir[1]==$b){?> selected <?php }?>> 
                                <?php echo $b?>
                              </option>
                              <?php
                              $b++; 
                            }
                            ?>
                          </select>
                          <select name="cbo_thn1">
                            <option value="">-Thn-</option>
                            <?php
                            $t=1970;
                            do{
                              ?>
                              <option value="<?php echo $t?>" <?php if($lahir[0]==$t){?> selected <?php }?>>
                                <?php echo $t?>
                              </option>
                              <?php
                              $t++;
                            }while($t<=date("Y"));
                            ?>
                          </select>
                        </div><br>
                      </div>
                    </div><br>                        

                    <!-- Text input-->
                    <div class="form-group">
                      <label class="col-md-2 control-label" for="nama_ibu_kandung">Nama Ibu Kandung</label>                      
                      <div class="col-md-4">
                        <input value="<?php echo $hasil->nama_ibu_kandung?>" id="nama_ibu_kandung" name="nama_ibu_kandung" type="text" placeholder="Nama Ibu Kandung"  class="form-control input-md">
                      </div><br>
                    </div><br>    

                    <div class="col-md-12">
                      <div class="alert info">                                                
                        <strong> 3. Data Pribadi</strong>
                      </div><br>      
                    </div><br><br><br><br><br>   

                    <!-- Text input-->
                    <div class="form-group">
                      <label class="col-md-2 control-label" for="tempat_tinggal">Tempat Tinggal</label>                      
                      <div class="col-md-4">
                        <input value="<?php echo $hasil->tempat_tinggal?>" id="tempat_tinggal" name="tempat_tinggal" type="text" placeholder="Tempat Tinggal"  class="form-control input-md">
                      </div><br>
                    </div><br>           

                    <!-- Text input-->
                    <div class="form-group">
                      <label class="col-md-2 control-label" for="dusun">Dusun</label>                      
                      <div class="col-md-4">
                        <input value="<?php echo $hasil->dusun?>" id="dusun" name="dusun" type="text" placeholder="Dusun"  class="form-control input-md">
                      </div><br>
                    </div><br>      

                    <!-- Text input-->
                    <div class="form-group">
                      <label class="col-md-2 control-label" for="kelurahan_desa">Kelurahan/Desa</label>                      
                      <div class="col-md-4">
                        <input value="<?php echo $hasil->kelurahan_desa?>" id="kelurahan_desa" name="kelurahan_desa" type="text" placeholder="Kelurahan/Desa"  class="form-control input-md">                                              
                      </div>
                      <label class="col-md-1 control-label" for="kode_pos">Kode Pos</label>                      
                      <div class="col-md-4">
                        <input value="<?php echo $hasil->kode_pos?>" id="kode_pos" name="kode_pos" type="text" placeholder="Kode Pos"  class="form-control input-md">                                              
                      </div><br>
                    </div><br>                                                               

                  <?php 
                    #ambil data kecamatan
                    $query = "SELECT id_kecamatan, kecamatan FROM mt_kecamatan  WHERE `aktif` like 'aktif'";
                    $sql = mysqli_query($con, $query);
                    $arrmt_kecamatan = array();
                    while ($row = mysqli_fetch_assoc($sql)) {
                    $arrmt_kecamatan [ $row['id_kecamatan'] ] = $row['kecamatan'];
                    }
                    ?>

                     <!-- select -->
                  <div class="form-group">
                    <label class="col-md-2 control-label" for="kecamatan">Kecamatan</label>
                                           
                    <div class="col-md-3">
                      <span class="inputan">
                        <select id="kecamatan" name="kecamatan">
                          <option value=""><?php echo $hasil->kecamatan?></option>
                          <?php
                          foreach ($arrmt_kecamatan as $id_kecamatan=>$kecamatan) {
                            echo "<option value='$kecamatan'>$kecamatan</option>";
                          }
                          ?>
                        </select>
                      </span>
                    </div><br>
                  </div><br>

                  <!-- Text input-->
                    <div class="form-group">
                      <label class="col-md-2 control-label" for="kab_kota">Kabupaten / Kota</label>                      
                      <div class="col-md-4">
                        <input value="<?php echo $hasil->kab_kota?>" id="kab_kota" name="kab_kota" type="text" placeholder="Kabupaten / Kota"  class="form-control input-md">
                      </div><br>
                    </div><br>  

                    <!-- Text input-->
                    <div class="form-group">
                      <label class="col-md-2 control-label" for="propinsi">Propinsi</label>                      
                      <div class="col-md-4">
                        <input value="<?php echo $hasil->propinsi?>" id="propinsi" name="propinsi" type="text" placeholder="Propinsi"  class="form-control input-md">
                      </div><br>
                    </div><br>    

                    <?php 
                    #ambil data agama
                    $query = "SELECT id_agama, agama FROM mt_agama  WHERE `aktif` like 'aktif'";
                    $sql = mysqli_query($con, $query);
                    $arrmt_agama = array();
                    while ($row = mysqli_fetch_assoc($sql)) {
                    $arrmt_agama [ $row['id_agama'] ] = $row['agama'];
                    }
                    ?>

                     <!-- select -->
                  <div class="form-group">
                    <label class="col-md-2 control-label" for="agama">Agama</label>
                                           
                    <div class="col-md-3">
                      <span class="inputan">
                        <select id="agama" name="agama">
                          <option value=""><?php echo $hasil->agama?></option>
                          <?php
                          foreach ($arrmt_agama as $id_agama=>$agama) {
                            echo "<option value='$agama'>$agama</option>";
                          }
                          ?>
                        </select>
                      </span>
                    </div><br>
                  </div><br>    

                  <!-- Text input-->
                    <div class="form-group">
                      <label class="col-md-2 control-label" for="npwp">NPWP</label>Di isi bagi yang memiliki                      
                      <div class="col-md-4">
                        <input value="<?php echo $hasil->npwp?>" id="npwp" name="npwp" type="text" placeholder="NPWP"  class="form-control input-md">
                      </div><br>
                    </div><br> 

                    <!-- select -->
                  <div class="form-group">
                    <label class="col-md-2 control-label" for="kewarganegaraan">Kewarganegaraan</label>                    
                    <div class="col-md-1">                     
                      <select name="kewarganegaraan">
                        <option value=""><?php echo $hasil->kewarganegaraan?></option>
                        <?php 
                        $kewarganegaraan = array("Indonesia (WNI)","Asing (WNA)");
                        foreach($kewarganegaraan as $k){
                          ?>
                          <option value="<?php echo $k?>">
                            <?php echo $k?>
                          </option>
                          <?php
                        }
                        ?>
                      </select>
                    </div><br>
                  </div><br>       

                    <?php 
                    #ambil data status kawin
                    $query = "SELECT id_status_kawin, status_kawin FROM mt_status_kawin WHERE `aktif` like 'aktif'";
                    $sql = mysqli_query($con, $query);
                    $arrmt_status_kawin = array();
                    while ($row = mysqli_fetch_assoc($sql)) {
                    $arrmt_status_kawin [ $row['id_status_kawin'] ] = $row['status_kawin'];
                    }
                    ?>

                     <!-- select -->
                  <div class="form-group">
                    <label class="col-md-2 control-label" for="status_kawin">Status Kawin</label>
                                           
                    <div class="col-md-3">
                      <span class="inputan">
                        <select id="status_kawin" name="status_kawin">
                          <option value=""><?php echo $hasil->status_kawin?></option>
                          <?php
                          foreach ($arrmt_status_kawin as $id_status_kawin=>$status_kawin) {
                            echo "<option value='$status_kawin'>$status_kawin</option>";
                          }
                          ?>
                        </select>
                      </span>
                    </div><br>
                  </div><br>

                  <!-- Text input-->
                    <div class="form-group">
                      <label class="col-md-2 control-label" for="nama_suami_istri">Nama Suami/Istri</label>
                      <div class="col-md-4">
                        <input value="<?php echo $hasil->nama_suami_istri?>" id="nama_suami_istri" name="nama_suami_istri" type="text" placeholder="Nama Suami/Istri"  class="form-control input-md">
                      </div><br>
                    </div><br> 

                    <?php 
                    #ambil data pekerjaan
                    $query = "SELECT id_pekerjaan, pekerjaan FROM mt_pekerjaan  WHERE `aktif` like 'aktif'";
                    $sql = mysqli_query($con, $query);
                    $arrmt_pekerjaan = array();
                    while ($row = mysqli_fetch_assoc($sql)) {
                    $arrmt_pekerjaan [ $row['id_pekerjaan'] ] = $row['pekerjaan'];
                    }
                    ?>

                     <!-- select -->
                  <div class="form-group">
                    <label class="col-md-2 control-label" for="pekerjan_suami_istri">Pekerjaan Suami/Istri</label>                    
                    <div class="col-md-4">
                      <span class="inputan">
                        <select id="pekerjan_suami_istri" name="pekerjan_suami_istri">
                          <option value=""><?php echo $hasil->pekerjan_suami_istri?></option>
                          <?php
                          foreach ($arrmt_pekerjaan as $id_pekerjaan=>$pekerjaan) {
                            echo "<option value='$pekerjaan'>$pekerjaan</option>";
                          }
                          ?>
                        </select>
                      </span>                                          
                    </div>
                    <label class="col-md-1 control-label" for="jika_pns_nip">Jika PNS, (NIP)</label>                      
                      <div class="col-md-4">
                        <input value="<?php echo $hasil->jika_pns_nip?>" id="jika_pns_nip" name="jika_pns_nip" type="text" placeholder="Jika PNS, (NIP)"  class="form-control input-md">                                              
                      </div><br>
                  </div><br>

                  <div class="col-md-12">
                      <div class="alert info">                                                
                        <strong> 4. Data Kepegawaian</strong>
                      </div><br>      
                    </div><br><br><br><br><br>                   

                  <?php 
                    #ambil data pekerjaan
                    $query = "SELECT id_pekerjaan, pekerjaan FROM mt_pekerjaan  WHERE `aktif` like 'aktif'";
                    $sql = mysqli_query($con, $query);
                    $arrmt_pekerjaan = array();
                    while ($row = mysqli_fetch_assoc($sql)) {
                    $arrmt_pekerjaan [ $row['id_pekerjaan'] ] = $row['pekerjaan'];
                    }
                    ?>

                     <!-- select -->
                  <div class="form-group">
                    <label class="col-md-2 control-label" for="status_kepegawaian">Status Kepegawaian</label>                    
                    <div class="col-md-4">
                      <span class="inputan">
                        <select id="status_kepegawaian" name="status_kepegawaian">
                          <option value=""><?php echo $hasil->status_kepegawaian?></option>
                          <?php
                          foreach ($arrmt_pekerjaan as $id_pekerjaan=>$pekerjaan) {
                            echo "<option value='$pekerjaan'>$pekerjaan</option>";
                          }
                          ?>
                        </select>
                      </span>                                          
                    </div>
                    <label class="col-md-1 control-label" for="jika_pns">Jika PNS, (NIP)</label>                      
                      <div class="col-md-4">
                        <input value="<?php echo $hasil->jika_pns?>" id="jika_pns" name="jika_pns" type="text" placeholder="Jika PNS, (NIP)"  class="form-control input-md">                                              
                      </div><br>
                  </div><br><br>

                    <!-- Text input-->
                    <div class="form-group">
                      <label class="col-md-2 control-label" for="niy_ngk">NIY/NGK</label>                      
                      <div class="col-md-4">
                        <input value="<?php echo $hasil->niy_ngk?>" id="niy_ngk" name="niy_ngk" type="text" placeholder="NIY/NGK"  class="form-control input-md">
                      </div><br>
                    </div><br>      

                    <!-- Text input-->
                    <div class="form-group">
                      <label class="col-md-2 control-label" for="nigb">NIGB</label>Di isikan bagi yang berstatus guru bantu                     
                      <div class="col-md-4">
                        <input value="<?php echo $hasil->nigb?>" id="nigb" name="nigb" type="text" placeholder="NIGB"  class="form-control input-md">
                      </div><br>
                    </div><br>      

                    <!-- Text input-->
                    <div class="form-group">
                      <label class="col-md-2 control-label" for="nuptk">NUPTK</label>Diisi bagi yang sudah memiliki (Lihat Pedoman)                   
                      <div class="col-md-4">
                        <input value="<?php echo $hasil->nuptk?>" id="nuptk" name="nuptk" type="text" placeholder="NUPTK"  class="form-control input-md">
                      </div><br>
                    </div><br>     

                    <?php 
                    #ambil data jenis PTK
                    $query = "SELECT id_jenis_ptk, jenis_ptk FROM mt_jenis_ptk  WHERE `aktif` like 'aktif'";
                    $sql = mysqli_query($con, $query);
                    $arrmt_jenis_ptk = array();
                    while ($row = mysqli_fetch_assoc($sql)) {
                    $arrmt_jenis_ptk [ $row['id_jenis_ptk'] ] = $row['jenis_ptk'];
                    }
                    ?>

                     <!-- select -->
                  <div class="form-group">
                    <label class="col-md-2 control-label" for="jenis_ptk">Jenis PTK</label>
                                           
                    <div class="col-md-3">
                      <span class="inputan">
                        <select id="jenis_ptk" name="jenis_ptk">
                          <option value=""><?php echo $hasil->jenis_ptk?></option>
                          <?php
                          foreach ($arrmt_jenis_ptk as $id_jenis_ptk=>$jenis_ptk) {
                            echo "<option value='$jenis_ptk'>$jenis_ptk</option>";
                          }
                          ?>
                        </select>
                      </span>
                    </div><br>
                  </div><br>   

                    <!-- Text input-->
                    <div class="form-group">
                      <label class="col-md-2 control-label" for="status_aktif">Status Aktif</label>                      
                      <div class="col-md-4">
                        <input value="<?php echo $hasil->status_aktif?>" id="status_aktif" name="status_aktif" type="text" placeholder="Status Aktif"  class="form-control input-md">
                      </div><br>
                    </div><br>      

                    <!-- Text input-->
                    <div class="form-group">
                      <label class="col-md-2 control-label" for="sk_pengangkatan">SK Pengangkatan</label>                      
                      <div class="col-md-4">
                        <input value="<?php echo $hasil->sk_pengangkatan?>" id="sk_pengangkatan" name="sk_pengangkatan" type="text" placeholder="SK Pengangkatan"  class="form-control input-md">
                      </div>
                       <!-- Radio Button -->
                      <div class="form-group">
                        <label class="col-md-1 control-label" for="">TMT Pengangkatan</label>                    
                        <div class="col-md-3">                                               
                          <?php
                          $lahir2 = explode("-", $hasil->tmt_pengangkatan);
                          ?>
                          <select name="cbo_tgl2">
                            <option value="">-Tgl-</option>
                            <?php
                            for($i=1; $i<=31; $i++){
                              ?>
                              <option value="<?php echo $i?>" <?php if($lahir2[2]==$i){?> selected <?php }?>>
                                <?php echo $i?>
                              </option>
                              <?php
                            }
                            ?>  
                          </select>
                          <select name="cbo_bln2">
                            <option value="">-Bln-</option>
                            <?php
                            $b =1;
                            while($b<=12){
                              ?>
                              <option value="<?php echo $b?>" <?php if($lahir2[1]==$b){?> selected <?php }?>> 
                                <?php echo $b?>
                              </option>
                              <?php
                              $b++; 
                            }
                            ?>
                          </select>
                          <select name="cbo_thn2">
                            <option value="">-Thn-</option>
                            <?php
                            $t=1970;
                            do{
                              ?>
                              <option value="<?php echo $t?>" <?php if($lahir2[0]==$t){?> selected <?php }?>>
                                <?php echo $t?>
                              </option>
                              <?php
                              $t++;
                            }while($t<=date("Y"));
                            ?>
                          </select>
                        </div><br>
                      </div>
                    </div><br>                        
                         

                                      <?php 
                    #ambil data jenis lembaga
                    $query = "SELECT id_lembaga, lembaga FROM mt_lembaga  WHERE `aktif` like 'aktif'";
                    $sql = mysqli_query($con, $query);
                    $arrmt_lembaga = array();
                    while ($row = mysqli_fetch_assoc($sql)) {
                    $arrmt_lembaga [ $row['id_lembaga'] ] = $row['lembaga'];
                    }
                    ?>

                     <!-- select -->
                  <div class="form-group">
                    <label class="col-md-2 control-label" for="lembaga_pengangkatan">Lembaga Pengangkatan</label>
                                           
                    <div class="col-md-3">
                      <span class="inputan">
                        <select id="lembaga_pengangkatan" name="lembaga_pengangkatan">
                          <option value=""><?php echo $hasil->lembaga_pengangkatan?></option>
                          <?php
                          foreach ($arrmt_lembaga as $id_lembaga=>$lembaga) {
                            echo "<option value='$lembaga'>$lembaga</option>";
                          }
                          ?>
                        </select>
                      </span>
                    </div><br>
                  </div><br>

                   <!-- Text input-->
                    <div class="form-group">
                      <label class="col-md-2 control-label" for="sk_cpns">SK CPNS</label>
                      <div class="col-md-4">
                        <input value="<?php echo $hasil->sk_pengangkatan?>" id="sk_cpns" name="sk_cpns" type="text" placeholder="SK CPNS"  class="form-control input-md">
                      </div><br>
                    </div><br>   

                     <!-- Radio Button -->
                      <div class="form-group">
                        <label class="col-md-2 control-label" for="">TMT CPNS</label>                    
                        <div class="col-md-3">                     
                           <?php
                          $lahir3 = explode("-", $hasil->tmt_cpns);
                          ?>
                          <select name="cbo_tgl3">
                            <option value="">-Tgl-</option>
                            <?php
                            for($i=1; $i<=31; $i++){
                              ?>
                              <option value="<?php echo $i?>" <?php if($lahir3[2]==$i){?> selected <?php }?>>
                                <?php echo $i?>
                              </option>
                              <?php
                            }
                            ?>  
                          </select>
                          <select name="cbo_bln3">
                            <option value="">-Bln-</option>
                            <?php
                            $b =1;
                            while($b<=12){
                              ?>
                              <option value="<?php echo $b?>" <?php if($lahir3[1]==$b){?> selected <?php }?>> 
                                <?php echo $b?>
                              </option>
                              <?php
                              $b++; 
                            }
                            ?>
                          </select>
                          <select name="cbo_thn3">
                            <option value="">-Thn-</option>
                            <?php
                            $t=1970;
                            do{
                              ?>
                              <option value="<?php echo $t?>" <?php if($lahir3[0]==$t){?> selected <?php }?>>
                                <?php echo $t?>
                              </option>
                              <?php
                              $t++;
                            }while($t<=date("Y"));
                            ?>
                          </select>
                        </div><br>
                      </div><br>

                       <!-- Radio Button -->
                      <div class="form-group">
                        <label class="col-md-2 control-label" for="">TMT PNS</label>                    
                        <div class="col-md-3">                     
                           <?php
                          $lahir4 = explode("-", $hasil->tmt_pns);
                          ?>
                          <select name="cbo_tgl4">
                            <option value="">-Tgl-</option>
                            <?php
                            for($i=1; $i<=31; $i++){
                              ?>
                              <option value="<?php echo $i?>" <?php if($lahir4[2]==$i){?> selected <?php }?>>
                                <?php echo $i?>
                              </option>
                              <?php
                            }
                            ?>  
                          </select>
                          <select name="cbo_bln4">
                            <option value="">-Bln-</option>
                            <?php
                            $b =1;
                            while($b<=12){
                              ?>
                              <option value="<?php echo $b?>" <?php if($lahir4[1]==$b){?> selected <?php }?>> 
                                <?php echo $b?>
                              </option>
                              <?php
                              $b++; 
                            }
                            ?>
                          </select>
                          <select name="cbo_thn4">
                            <option value="">-Thn-</option>
                            <?php
                            $t=1970;
                            do{
                              ?>
                              <option value="<?php echo $t?>" <?php if($lahir4[0]==$t){?> selected <?php }?>>
                                <?php echo $t?>
                              </option>
                              <?php
                              $t++;
                            }while($t<=date("Y"));
                            ?>
                          </select>
                        </div><br>
                      </div><br>

                    <?php 
                    #ambil data jenis golongan
                    $query = "SELECT id_golongan, golongan FROM mt_golongan  WHERE `aktif` like 'aktif'";
                    $sql = mysqli_query($con, $query);
                    $arrmt_golongan = array();
                    while ($row = mysqli_fetch_assoc($sql)) {
                    $arrmt_golongan [ $row['id_golongan'] ] = $row['golongan'];
                    }
                    ?>

                     <!-- select -->
                  <div class="form-group">
                    <label class="col-md-2 control-label" for="pangkat_gol">Pangkat/Golongan</label>
                                           
                    <div class="col-md-3">
                      <span class="inputan">
                        <select id="pangkat_gol" name="pangkat_gol">
                          <option value=""><?php echo $hasil->pangkat_gol?></option>
                          <?php
                          foreach ($arrmt_golongan as $id_golongan=>$golongan) {
                            echo "<option value='$golongan'>$golongan</option>";
                          }
                          ?>
                        </select>
                      </span>
                    </div><br>
                  </div><br>   

                    <?php 
                    #ambil data jenis sumber_gaji
                    $query = "SELECT id_sumber_gaji, sumber_gaji FROM mt_sumber_gaji  WHERE `aktif` like 'aktif'";
                    $sql = mysqli_query($con, $query);
                    $arrmt_sumber_gaji = array();
                    while ($row = mysqli_fetch_assoc($sql)) {
                    $arrmt_sumber_gaji [ $row['id_sumber_gaji'] ] = $row['sumber_gaji'];
                    }
                    ?>

                     <!-- select -->
                  <div class="form-group">
                    <label class="col-md-2 control-label" for="sumber_gaji">Sumber Gaji</label>
                                           
                    <div class="col-md-3">
                      <span class="inputan">
                        <select id="sumber_gaji" name="sumber_gaji">
                          <option value=""><?php echo $hasil->sumber_gaji?></option>
                          <?php
                          foreach ($arrmt_sumber_gaji as $id_sumber_gaji=>$sumber_gaji) {
                            echo "<option value='$sumber_gaji'>$sumber_gaji</option>";
                          }
                          ?>
                        </select>
                      </span>
                    </div>
                  </div><br>  

                    <?php 
                    #ambil data jenis jenis_guru
                    $query = "SELECT id_jenis_guru, jenis_guru FROM mt_jenis_guru  WHERE `aktif` like 'aktif'";
                    $sql = mysqli_query($con, $query);
                    $arrmt_jenis_guru = array();
                    while ($row = mysqli_fetch_assoc($sql)) {
                    $arrmt_jenis_guru [ $row['id_jenis_guru'] ] = $row['jenis_guru'];
                    }
                    ?>

                     <!-- select -->
                  <div class="form-group">
                    <label class="col-md-2 control-label" for="status_guru">Status Guru</label>
                                           
                    <div class="col-md-3">
                      <span class="inputan">
                        <select id="status_guru" name="status_guru">
                          <option value=""><?php echo $hasil->status_guru?></option>
                          <?php
                          foreach ($arrmt_jenis_guru as $id_jenis_guru=>$jenis_guru) {
                            echo "<option value='$jenis_guru'>$jenis_guru</option>";
                          }
                          ?>
                        </select>
                      </span>
                    </div>
                                        <?php 
                    #ambil data jenis akademik
                    $query = "SELECT id_akademik, akademik FROM mt_akademik  WHERE `aktif` like 'aktif'";
                    $sql = mysqli_query($con, $query);
                    $arrmt_akademik = array();
                    while ($row = mysqli_fetch_assoc($sql)) {
                    $arrmt_akademik [ $row['id_akademik'] ] = $row['akademik'];
                    }
                    ?>

                     <!-- select -->
                  <div class="form-group">
                    <label class="col-md-2 control-label" for="akademik">Akademik</label>
                                           
                    <div class="col-md-3">
                      <span class="inputan">
                        <select id="akademik" name="akademik">
                          <option value=""><?php echo $hasil->akademik?></option>
                          <?php
                          foreach ($arrmt_akademik as $id_akademik=>$akademik) {
                            echo "<option value='$akademik'>$akademik</option>";
                          }
                          ?>
                        </select>
                      </span>
                    </div>
                  </div><br>   
                  </div><br>

                    <?php 
                    #ambil data jenis bidang_studi
                    $query = "SELECT id_bidang_studi, nama_bidang_studi FROM mt_bidang_studi  WHERE `aktif` like 'aktif'";
                    $sql = mysqli_query($con, $query);
                    $arrmt_bidang_studi = array();
                    while ($row = mysqli_fetch_assoc($sql)) {
                    $arrmt_bidang_studi [ $row['id_bidang_studi'] ] = $row['nama_bidang_studi'];
                    }
                    ?>

                     <!-- select -->
                  <div class="form-group">
                    <label class="col-md-2 control-label" for="bidang_studi">Bidang Studi</label>
                                           
                    <div class="col-md-3">
                      <span class="inputan">
                        <select id="bidang_studi" name="bidang_studi">
                          <option value=""><?php echo $hasil->bidang_studi?></option>
                          <?php
                          foreach ($arrmt_bidang_studi as $id_bidang_studi=>$nama_bidang_studi) {
                            echo "<option value='$nama_bidang_studi'>$nama_bidang_studi</option>";
                          }
                          ?>
                        </select>
                      </span>
                    </div><br>
                  </div><br>   

                  <!-- select -->
                  <div class="form-group">
                    <label class="col-md-2 control-label" for="status">Status</label>                    
                    <div class="col-md-1">                     
                      <select name="status">
                        <option value=""><?php echo $hasil->status?></option>
                        <?php 
                        $status = array("pendidik ","kependidikan ");
                        foreach($status as $s){
                          ?>
                          <option value="<?php echo $s?>">
                            <?php echo $s?>
                          </option>
                          <?php
                        }
                        ?>
                      </select>
                    </div><br>
                  </div><br>       

                  <!-- Radio Button -->
                  <div class="form-group">
                    <label class="col-md-3 control-label" for=""></label>
                    <label class="col-md-2 control-label"></label>  
                    <div class="col-md-1">                     
                      <button type="submit" class="btn btn-primary"> Daftar</button>
                    </div><br>
                  </div><br>                 

                </fieldset>
              </form>       
      </div>  
    </div>
  </div>  

<?php  
 include "../library/footerdisdik.php";
?>    
