<?php
	include "../../koneksi.php";
	$id = $_GET["id"];
	$sql = "DELETE FROM `rb_agenda` WHERE `id_agenda`='".$id."' ";
	mysqli_query($con,$sql) or die(mysqli_error($con));
	header("location:../daftaragenda.php");

?>