<?php
	include "../../koneksi.php";
	$id = $_GET["id"];
	$sql = "DELETE FROM `mt_akademik` WHERE `akademik`='".$id."' ";
	mysqli_query($con,$sql) or die(mysqli_error($con));
	header("location:../master/mt_akademik.php?salah=<strong>Berhasil Menghapus!<br><br>");

?>