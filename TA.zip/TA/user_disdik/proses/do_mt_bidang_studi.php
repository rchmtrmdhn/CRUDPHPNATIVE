<?php
	include "../../koneksi.php";

	$bidang_studi = $_POST["bidang_studi"];
	$aktif = $_POST["aktif"];
	

	
	
 
	$sql = "SELECT * FROM `mt_bidang_studi` WHERE `nama_bidang_studi`='".$bidang_studi."' ";
	$query = mysqli_query($con,$sql) or die(mysqli_error($con));
	$jumlah = mysqli_num_rows($query); 

	if($bidang_studi==""){
		header("location:../master/mt_bidang_studi.php?salah=<strong>Harap isi Data");

	}else if($jumlah > 0){
		header("location:../master/mt_bidang_studi.php?salah=<strong>Data sudah digunakan<br><br>");
			
	}else if($aktif==""){
		header("location:../master/mt_bidang_studi.php?salah=<strong>Harap isi Status<br><br>");
	}	
	else{		
		$sql = "INSERT INTO `mt_bidang_studi` (`nama_bidang_studi`,`aktif`)
		VALUES
		('".$bidang_studi."','".$aktif."')"; 
		mysqli_query($con,$sql) or die(mysqli_error($con));
				
			
		header("location:../master/mt_bidang_studi.php?salah=<strong>Registrasi Berhasil<br><br>");	
	}
	
?>