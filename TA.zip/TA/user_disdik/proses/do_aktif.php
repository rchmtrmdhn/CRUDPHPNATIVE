<?php

include "../../koneksi.php";

$id = $_GET['id'];
$sql = "SELECT * FROM `mt_agama` WHERE `id_agama`='".$id."'";
$stts = $_GET['aktif'];

if ($stts=='Aktif'){

$update = "UPDATE `aktif` set aktif='Aktif' where id_agama = '$id' ";

print"<script>alert('Berhasil Mengaktifkan'); location='../aktif.php'</script>";

exit();

}else {

$update = "UPDATE `aktif` set aktif='Nonaktif' where id_agama = '$id' ";

print"<script>alert('Berhasil Menonaktifkan'); location='../aktif.php'</script>";

exit();

}

die("Terdapat kesalahan : ".mysqli_error($con));

?>