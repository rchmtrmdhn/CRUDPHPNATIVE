<?php
	include "../../koneksi.php";
	$id = $_GET["id"];
	$sql = "DELETE FROM `rb_users` WHERE `aemail`='".$id."' ";
	mysqli_query($con,$sql) or die(mysqli_error($con));
	header("location:../kelolauserssekolah.php");

?>