<?php
	include "../../koneksi.php";

	$agama = $_POST["agama"];
	$aktif = $_POST["aktif"];
	

	
	
 
	$sql = "SELECT * FROM `mt_agama` WHERE `agama`='".$agama."' ";
	$query = mysqli_query($con,$sql) or die(mysqli_error($con));
	$jumlah = mysqli_num_rows($query); 

	if($agama==""){
		header("location:../master/mt_agama.php?salah=<strong>Harap isi Data");

	}else if($jumlah > 0){
		header("location:../master/mt_agama.php?salah=<strong>Data sudah digunakan<br><br>");
			
	}else if($aktif==""){
		header("location:../master/mt_agama.php?salah=<strong>Harap isi Status<br><br>");
	}	
	else{		
		$sql = "INSERT INTO `mt_agama` (`agama`,`aktif`)
		VALUES
		('".$agama."','".$aktif."')"; 
		mysqli_query($con,$sql) or die(mysqli_error($con));
				
			
		header("location:../master/mt_agama.php?salah=<strong>Registrasi Berhasil<br><br>");	
	}
	
?>