<?php
	include("../../mysql.php");
	include('../../config.php');
	$id = $_GET["id"];
	$sql = "DELETE FROM `download` WHERE `id`='".$id."' ";
	mysql_query($sql);
	header("location:../download.php");

?>