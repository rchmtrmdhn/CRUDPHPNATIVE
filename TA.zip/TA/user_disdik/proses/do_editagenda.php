<?php 
include "../../koneksi.php";
$id = $_GET["id"];

$txt_np = $_POST["txt_np"];
$txt_nik = $_POST["txt_nik"];
$txt_pic = $_POST["txt_pic"];
$txt_keterangan = $_POST["txt_keterangan"];

$txt_selesai1 = $_POST["txt_selesai1"];
$txt_selesai2 = $_POST["txt_selesai2"];
$txt_selesai3 = $_POST["txt_selesai3"];
$txt_selesai4 = $_POST["txt_selesai4"];

$tgl = $_POST["cbo_tgl"];
$bln = $_POST["cbo_bln"];
$thn = $_POST["cbo_thn"];
$tgl2 = $_POST["cbo_tgl2"];
$bln2 = $_POST["cbo_bln"];
$thn2 = $_POST["cbo_thn2"];

$file1 = $_FILES["btn_file1"];
$file2 = $_FILES["btn_file2"];
$file3 = $_FILES["btn_file3"];
$file4 = $_FILES["btn_file4"];

$tanggal_mulai = $thn."-".$bln."-".$tgl;
$tanggal_berakhir = $thn2."-".$bln2."-".$tgl2;
if($txt_np==""){
	header("location:../editagenda.php?salah=Harap isi Nomor Proyek&id=".$id);
}else if($txt_nik==""){
	header("location:../editagenda.php?salah=Harap isi NIK&id=".$id);
}else if($txt_pic==""){
	header("location:../editagenda.php?salah=Harap isi PIC&id=".$id);
}else if($tgl=="" || $bln=="" || $thn==""){
	header("location:../editagenda.php?salah=Harap isi tanggal mulai&id=".$id);
}else if($tgl2=="" || $bln2=="" || $thn2==""){
	header("location:../editagenda.php?salah=Harap isi tanggal berakhir&id=".$id);
}else{
	$tanggal_mulai = $thn."-".$bln."-".$tgl;
	$tanggal_berakhir = $thn2."-".$bln2."-".$tgl2;
	if($file1["name"]!=""){
		move_uploaded_file($file1["tmp_name"], "../../img/".$file1["name"]);
		$sql="UPDATE `rb_agenda` SET 
		`np`='".$txt_np."',
		`nik`='".$txt_nik."',
		`pic`='".$txt_pic."',
		`keterangan`='".$txt_keterangan."',
		`tanggal_mulai`='".$tanggal_mulai."',
		`tanggal_berakhir`='".$tanggal_berakhir."',
		`file1`='".$file1["name"]."' WHERE `np`='".$id."'";
		// die("test");
	}else if($file2["name"]!=""){
		move_uploaded_file($file2["tmp_name"], "../../img/".$file2["name"]);
		$sql="UPDATE `rb_agenda` SET 
		`np`='".$txt_np."',
		`nik`='".$txt_nik."',
		`pic`='".$txt_pic."',
		`keterangan`='".$txt_keterangan."',
		`tanggal_mulai`='".$tanggal_mulai."',
		`tanggal_berakhir`='".$tanggal_berakhir."',
		`file2`='".$file2["name"]."' WHERE `np`='".$id."'";
		// die("test");
	}
	else if($file3["name"]!=""){
		move_uploaded_file($file3["tmp_name"], "../../img/".$file3["name"]);
		$sql="UPDATE `rb_agenda` SET 
		`np`='".$txt_np."',
		`nik`='".$txt_nik."',
		`pic`='".$txt_pic."',
		`keterangan`='".$txt_keterangan."',
		`tanggal_mulai`='".$tanggal_mulai."',
		`tanggal_berakhir`='".$tanggal_berakhir."',
		`file3`='".$file3["name"]."' WHERE `np`='".$id."'";
		// die("test");
	}
	else if($file4["name"]!=""){
		move_uploaded_file($file4["tmp_name"], "../../img/".$file4["name"]);
		$sql="UPDATE `rb_agenda` SET 
		`np`='".$txt_np."',
		`nik`='".$txt_nik."',
		`pic`='".$txt_pic."',
		`keterangan`='".$txt_keterangan."',
		`tanggal_mulai`='".$tanggal_mulai."',
		`tanggal_berakhir`='".$tanggal_berakhir."',
		`file4`='".$file4["name"]."' WHERE `np`='".$id."'";
		// die("test");
	}
	else{ 
		$sql="UPDATE `rb_agenda` SET
		`np`='".$txt_np."',
		`nik`='".$txt_nik."',
		`pic`='".$txt_pic."',
		`keterangan`='".$txt_keterangan."',
		`tanggal_mulai`='".$tanggal_mulai."',
		`tanggal_berakhir`='".$tanggal_berakhir."'
		WHERE `np`='".$id."'";
	}
	mysqli_query($con,$sql) or die(mysqli_error($con));
	header("location:../daftaragenda.php");
}

?>
