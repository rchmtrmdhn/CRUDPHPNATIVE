<?php
	include "../../koneksi.php";

	$jenis_guru = $_POST["jenis_guru"];
	$aktif = $_POST["aktif"];
			
 
	$sql = "SELECT * FROM `mt_jenis_guru` WHERE `jenis_guru`='".$jenis_guru."' ";
	$query = mysqli_query($con,$sql) or die(mysqli_error($con));
	$jumlah = mysqli_num_rows($query); 

	if($jenis_guru==""){
		header("location:../master/mt_jenis_guru.php?salah=<strong>Harap isi Data");

	}else if($jumlah > 0){
		header("location:../master/mt_jenis_guru.php?salah=<strong>Data sudah digunakan<br><br>");
			
	}else if($aktif==""){
		header("location:../master/mt_jenis_guru.php?salah=<strong>Harap isi Status<br><br>");
	}	
	else{		
		$sql = "INSERT INTO `mt_jenis_guru` (`jenis_guru`,`aktif`)
		VALUES
		('".$jenis_guru."','".$aktif."')"; 
		mysqli_query($con,$sql) or die(mysqli_error($con));
				
			
		header("location:../master/mt_jenis_guru.php?salah=<strong>Registrasi Berhasil<br><br>");	
	}
	
?>