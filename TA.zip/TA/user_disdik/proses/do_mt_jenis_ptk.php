<?php
	include "../../koneksi.php";

	$jenis_ptk = $_POST["jenis_ptk"];
	$aktif = $_POST["aktif"];
			
 
	$sql = "SELECT * FROM `mt_jenis_ptk` WHERE `jenis_ptk`='".$jenis_ptk."' ";
	$query = mysqli_query($con,$sql) or die(mysqli_error($con));
	$jumlah = mysqli_num_rows($query); 

	if($jenis_ptk==""){
		header("location:../master/mt_jenis_ptk.php?salah=<strong>Harap isi Data");

	}else if($jumlah > 0){
		header("location:../master/mt_jenis_ptk.php?salah=<strong>Data sudah digunakan<br><br>");
			
	}else if($aktif==""){
		header("location:../master/mt_jenis_ptk.php?salah=<strong>Harap isi Status<br><br>");
	}	
	else{		
		$sql = "INSERT INTO `mt_jenis_ptk` (`jenis_ptk`,`aktif`)
		VALUES
		('".$jenis_ptk."','".$aktif."')"; 
		mysqli_query($con,$sql) or die(mysqli_error($con));
				
			
		header("location:../master/mt_jenis_ptk.php?salah=<strong>Registrasi Berhasil<br><br>");	
	}
	
?>