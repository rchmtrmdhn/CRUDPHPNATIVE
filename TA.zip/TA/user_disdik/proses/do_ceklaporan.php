<?php
include "../../koneksi.php";
$id = $_GET["id"];

$txt_np = $_POST["txt_np"];
$id_user = $_POST["id_user"];
$tanggal = $_POST["tanggal"];
$txt_selesai1 = $_POST["txt_selesai1"];
$txt_selesai2 = $_POST["txt_selesai2"];
$txt_selesai3 = $_POST["txt_selesai3"];
$txt_selesai4 = $_POST["txt_selesai4"];

	$sql="UPDATE `rb_laporan` SET 
		`np`='".$txt_np."',
		`id_user`='".$id_user."',
		`tanggal`='".$tanggal."',
		`selesai1`='".$txt_selesai1."',
		`selesai2`='".$txt_selesai2."',
		`selesai3`='".$txt_selesai3."',
		`selesai4`='".$txt_selesai4."'
		WHERE `id_laporan`='".$id."'";

	mysqli_query($con,$sql) or die(mysqli_error($con));
	header("location:../ceklaporan.php");
?>