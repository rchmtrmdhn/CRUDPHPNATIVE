<?php
	include "../../koneksi.php";
	unset($_SESSION["admin"]);
	header("location:../../index.php");

?>