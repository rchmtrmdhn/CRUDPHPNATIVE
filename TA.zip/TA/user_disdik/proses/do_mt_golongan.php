<?php
	include "../../koneksi.php";

	$golongan = $_POST["golongan"];
	$aktif = $_POST["aktif"];
			
 
	$sql = "SELECT * FROM `mt_golongan` WHERE `golongan`='".$golongan."' ";
	$query = mysqli_query($con,$sql) or die(mysqli_error($con));
	$jumlah = mysqli_num_rows($query); 

	if($golongan==""){
		header("location:../master/mt_golongan.php?salah=<strong>Harap isi Data");

	}else if($jumlah > 0){
		header("location:../master/mt_golongan.php?salah=<strong>Data sudah digunakan<br><br>");
			
	}else if($aktif==""){
		header("location:../master/mt_golongan.php?salah=<strong>Harap isi Status<br><br>");
	}	
	else{		
		$sql = "INSERT INTO `mt_golongan` (`golongan`,`aktif`)
		VALUES
		('".$golongan."','".$aktif."')"; 
		mysqli_query($con,$sql) or die(mysqli_error($con));
				
			
		header("location:../master/mt_golongan.php?salah=<strong>Registrasi Berhasil<br><br>");	
	}
	
?>