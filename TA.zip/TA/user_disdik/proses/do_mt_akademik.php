<?php
	include "../../koneksi.php";

	$akademik = $_POST["akademik"];
	$aktif = $_POST["aktif"];
	

	
	
 
	$sql = "SELECT * FROM `mt_akademik` WHERE `akademik`='".$akademik."' ";
	$query = mysqli_query($con,$sql) or die(mysqli_error($con));
	$jumlah = mysqli_num_rows($query); 

	if($akademik==""){
		header("location:../master/mt_akademik.php?salah=<strong>Harap isi Data");

	}else if($jumlah > 0){
		header("location:../master/mt_akademik.php?salah=<strong>Data sudah digunakan<br><br>");
			
	}else if($aktif==""){
		header("location:../master/mt_akademik.php?salah=<strong>Harap isi Status<br><br>");
	}	
	else{		
		$sql = "INSERT INTO `mt_akademik` (`akademik`,`aktif`)
		VALUES
		('".$akademik."','".$aktif."')"; 
		mysqli_query($con,$sql) or die(mysqli_error($con));
				
			
		header("location:../master/mt_akademik.php?salah=<strong>Registrasi Berhasil<br><br>");	
	}
	
?>