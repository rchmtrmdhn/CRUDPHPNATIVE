<?php 
	include "../../koneksi.php";
	$id = $_GET["id"];

	$nama = $_POST["txt_nama"];
	$email = $_POST["txt_email"];

	if($nama==""){
		header("location:../cekinbox.php?salah=Harap isi Nama Pengguna&id=".$id);
	}else if($email==""){
		header("location:../cekinbox.php?salah=Harap isi email&id=".$id);	
	}

	else{
		
		if{		
		$sql="UPDATE `rb_hubungi` SET 
		`nama`='".$nama."',	
		`email`='".$email."',		
			WHERE `nama`='".$id."'";
		// die("test");
		}else{ 
			$sql="UPDATE `rb_hubungi` SET
		`nama`='".$nama."',	
		`email`='".$email."',		
			 WHERE `nama`='".$id."'";
		}
		mysqli_query($con,$sql) or die(mysqli_error($con));
		header("location:../cekinbox.php");
	}

?>
