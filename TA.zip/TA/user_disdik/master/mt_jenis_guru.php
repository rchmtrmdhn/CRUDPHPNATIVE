<?php 
include "../../koneksi.php";
session_start();
if(isset($_SESSION['admin'])) {
  include('../../library/headermaster.php');
}else{
  include ('../../library/header.php');
  }
 ?> 

 <?php 
 if(empty($_SESSION["admin"])){
        header("location:../../index.php");
    } ?>
<!-- /. NAV SIDE  -->
<div id="page-wrapper" >
    <div id="page-inner">
        <div class="row">
            <div class="col-md-12">
             <h2>Master Jenis Guru</h2>                
           </div>
        </div>
     <!-- /. ROW  -->
     <hr>         

               <!-- start content -->
              <form method="post" action="../proses/do_mt_jenis_guru.php" enctype="multipart/form-data">
                <?php
                if(!empty($_GET["salah"])){
                  echo $_GET["salah"];
                }               
                ?>

                <form class="form-horizontal">
                  <fieldset>    

                    <!-- Text input-->
                    <div class="form-group">                      
                      <div class="col-md-4">
                        <input id="jenis_guru" name="jenis_guru" type="text" placeholder="Input Jenis Guru"  class="form-control input-md">
                      </div><button type="submit" class="btn btn-success">Tambah</button> <br><br>
                      <!-- select -->
                      <div class="form-group">                    
                        <label class="col-md-1 control-label" for="aktif">Status</label>
                        <div class="col-md-1">                     
                          <select name="aktif">
                            <option value="">-Pilih</option>
                            <?php 
                            $aktif = array("Aktif","Nonaktif");
                            foreach($aktif as $a){
                              ?>
                              <option value="<?php echo $a?>">
                                <?php echo $a?>
                              </option>
                              <?php
                            }
                            ?>
                          </select>
                        </div><br>
                      </div>

                    </div>                      

                  </fieldset>
                </form>   

              <div class="col-md-12">
              <div class="alert info">
                <?php
                  $sql = "SELECT * FROM `mt_jenis_guru` ";
                  $query = mysqli_query($con,$sql) or die(mysqli_error($con));
                  $jumlah = mysqli_num_rows($query);
                ?>
                <span class="closebtn">&times;</span>  
                Semua Data <strong>Jenis Guru - <?php echo $jumlah?> Terdaftar. </strong>
              </div>       
            </div>                                                  
                                             
                <?php
              
              $sql="SELECT * FROM `mt_jenis_guru`";            
              $query = mysqli_query($con,$sql) or die(mysqli_error($con));
              $jumlah = mysqli_num_rows($query);

              if($jumlah==0){
                echo "Data Tidak ada";
              }else{
                ?>                

                      <center>
                        <table id="example" class="table table-bordered" style="width:100%">
                        <thead>                                    
                          <tr>
                            <th>No.</th>                      
                            <th>Jenis Guru</th>
                            <th>Status</th>                            
                            <th>Action</th>                      
                          </tr>
                          </thead>
                          
                          <?php
                          $no = 1;
                          while($hasil = mysqli_fetch_object($query)){
                            ?>
                          
                            <tr>
                              <td><?php echo $no?></td>
                              <td><?php echo $hasil->jenis_guru ?></td>
                              <td><?php echo $hasil->aktif ?></td>
                              <td><a class="btn btn-danger"> <span class="fa fa-power-off"></span></a></td>                                        
                            </tr>
                          
                            <?php 
                            $no++;
                          } ?>
                          <tfoot>                                        
                          <tr>
                            <th>No.</th>                      
                            <th>Jenis Guru</th>
                            <th>Status</th>                            
                            <th>Action</th>                                                               
                          </tr>
                          </tfoot>
                        </table>
                        <?php } ?>
                  
                        </div>
                    </div>
                </div>
                
            </div>
            <!-- /.container -->

 </div> 

<?php
    include "../../library/footermaster.php";
?>      