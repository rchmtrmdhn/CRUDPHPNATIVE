<?php 
include "../../koneksi.php";
session_start();
if(isset($_SESSION['admin'])) {
  include('../../library/headermaster.php');
}else{
  include ('../../library/header.php');
  }
 ?> 

 <?php 
 if(empty($_SESSION["admin"])){
        header("location:../../index.php");
    } ?>
<!-- /. NAV SIDE  -->
<div id="page-wrapper" >
    <div id="page-inner">
        <div class="row">
            <div class="col-md-12">
             <h2>Master Data Sekolah</h2>                
           </div>
        </div>
     <!-- /. ROW  -->
     <hr>         

              <!-- BUTTON  -->
              <div class="col-md-6 col-sm-6 col-xs-6">                                 
                <a class="btn btn-primary" href="registerpendidik.php">Tambah Data</a>                                        
              </div><br><br><br>  
              <!-- END BUTTON -->

              <div class="col-md-12">
              <div class="alert info">
                <?php
                  $sql = "SELECT * FROM `mt_sekolah` ";
                  $query = mysqli_query($con,$sql) or die(mysqli_error($con));
                  $jumlah = mysqli_num_rows($query);
                ?>
                <span class="closebtn">&times;</span>  
                Semua Data <strong>Data Sekolah - <?php echo $jumlah?> Terdaftar. </strong>
              </div>       
            </div>                               
                                             
                <?php
              
              $sql="SELECT * FROM `mt_sekolah`";            
              $query = mysqli_query($con,$sql) or die(mysqli_error($con));
              $jumlah = mysqli_num_rows($query);

              if($jumlah==0){
                echo "Data Tidak ada";
              }else{
                ?>                

                      <center>
                        <table id="example" class="table table-bordered" style="width:100%">
                        <thead>                                    
                          <tr>
                            <th>No.</th>                      
                            <th>Nama Sekolah</th>
                            <th>No. Telp</th>  
                            <th>Website</th>  
                            <th>Alamat Sekolah</th>                               
                            <th>Action</th>                      
                          </tr>
                          </thead>
                          
                          <?php
                          $no = 1;
                          while($hasil = mysqli_fetch_object($query)){
                            ?>
                          
                            <tr>
                              <td><?php echo $no?></td>
                              <td><?php echo $hasil->nama_sekolah ?></td>
                              <td><?php echo $hasil->no_telp ?></td>
                              <td><?php echo $hasil->website ?></td>
                              <td><?php echo $hasil->alamat_sekolah ?></td>                                                          
                              <td><a class="btn btn-danger"> <span class="fa fa-power-off"></span></a></td>                                        
                            </tr>
                          
                            <?php 
                            $no++;
                          } ?>
                          <tfoot>                                        
                          <tr>
                            <th>No.</th>                      
                            <th>Nama Sekolah</th>
                            <th>No. Telp</th>  
                            <th>Website</th>  
                            <th>Alamat Sekolah</th>                              
                            <th>Action</th>                                                               
                          </tr>
                          </tfoot>
                        </table>
                        <?php } ?>
                  
                        </div>
                    </div>
                </div>
                
            </div>
            <!-- /.container -->        

 </div> 

<?php
    include "../../library/footermaster.php";
?>      