<?php 
include "../koneksi.php";
session_start();
if(isset($_SESSION['admin'])) {
  include('../library/headerdisdik.php');
}else{
  include ('../library/header.php');
}

?>
<?php 

if(empty($_SESSION["admin"])){
  header("location:../daftaragenda.php");
} 
$id = $_GET["id"];
?>
<!-- /. NAV SIDE  -->
<div id="page-wrapper" >
 <div id="page-inner">
  <div class="row">

    <form method="post" action="proses/do_ceklaporan.php?id=<?php echo $id?>" class="form-horizontal" enctype="multipart/form-data">
      <div class="col-md-12">

        <br><br>
        <!-- Form Name -->
        <legend>Cek Laporan</legend>
        <?php        
        $sql = "SELECT * FROM `rb_laporan` WHERE `id_laporan`='".$id."'";
        $query = mysqli_query($con,$sql) or die (mysqli_error($con));
        $hasil = mysqli_fetch_object($query);
        ?>
        <?php
        if(!empty($_GET["salah"])){
          echo $_GET["salah"];
        }
        ?>
        <!-- Name input-->
        <div class="form-group">
          <label class="col-md-4 control-label" for="txt_np">Nomor Proyek</label>
          <div class="col-md-4">
            <input id="txt_np" name="txt_np" type="text" value="<?php echo $hasil->np ?>" readonly class="form-control input-md">
         </div>
       </div>
       <!-- Name input-->
       <div class="form-group">
        <label class="col-md-4 control-label" for="txt_pengirim">Pengirim</label>
        <div class="col-md-4">
         <input id="id_user" name="id_user" type="text" value="<?php echo $hasil->id_user ?>" readonly class="form-control input-md">
       </div>
     </div>
     <!-- Radio Button -->
     <div class="form-group">
      <label class="col-md-4 control-label" for="">Tanggal Pengiriman Laporan</label>
      <div class="col-md-4">                     
        <input id="tanggal" name="tanggal" type="text" value="<?php echo $hasil->tanggal ?>" readonly class="form-control input-md">
      </div>
    </div>
    <!-- File Button -->
    <label class="col-md-4 control-label" for="btn_file">Dokumen Laporan</label>
    <div class="form-group">
      <label class="col-md-4 control-label" for="btn_file"></label>
      <div class="col-md-4">
        Dokumen 1
        <br>
        <a name="btn_file1" href="../img/<?php echo $hasil->file1?>"><?php echo $hasil->file1 ?></a>
        <br>
        <!-- Select Basic -->
        <select id="txt_selesai1" name="txt_selesai1" class="form-control">
          <option value="Belum Selesai">Belum Selesai</option>
          <option value="Selesai">Selesai</option>
        </select>
        Dokumen 2
        <br>
        <a name="btn_file2" href="../img/<?php echo $hasil->file2?>"><?php echo $hasil->file2 ?></a>
        <br>
        <!-- Select Basic -->
        <select id="txt_selesai2" name="txt_selesai2" class="form-control">
          <option value="Belum Selesai">Belum Selesai</option>
          <option value="Selesai">Selesai</option>
        </select>
        Dokumen 3
        <br>
        <a href="../img/<?php echo $hasil->file3?>"><?php echo $hasil->file3 ?></a>
        <br>
        <!-- Select Basic -->
        <select id="txt_selesai3" name="txt_selesai3" class="form-control">
         <option value="Belum Selesai">Belum Selesai</option>
         <option value="Selesai">Selesai</option>
       </select>
       Dokumen 4
       <br>
       <a name="btn_file4" href="../img/<?php echo $hasil->file4?>"><?php echo $hasil->file4 ?></a>
       <br>
       <!-- Select Basic -->
       <select id="txt_selesai4" name="txt_selesai4" class="form-control">
        <option value="Belum Selesai">Belum Selesai</option>
        <option value="Selesai">Selesai</option>
      </select>
    </div>
  </div>

  <!-- Button -->
  <div class="form-group">
    <label class="col-md-7 control-label" for="btn_upload"></label>
    <div class="col-md-4" >
     <button id="btn_upload" name="btn_upload" class="btn btn-primary">Kirim</button>
   </div>
 </div>

</div>	
</form>
</div>	
</div>
</div>

<?php  
include "../library/footerdisdik.php";
?> 		